<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Laporan Arus Kas</h1>
</div>

<!-- Filter Box -->
<div class="card shadow mb-4 border-left-success">
    <div class="card-body py-3">
        <form action="" method="get" class="form-inline">
            <label class="mr-2 font-weight-bold">Periode:</label>
            <select name="bulan" class="form-control mr-2">
                <?php for($m=1; $m<=12; $m++): ?>
                    <option value="<?= $m ?>" <?= ($filter_bln == $m) ? 'selected' : '' ?>><?= date('F', mktime(0, 0, 0, $m, 10)) ?></option>
                <?php endfor; ?>
            </select>
            <input type="number" name="tahun" class="form-control mr-3" value="<?= $filter_thn ?>" style="width: 100px;">
            
            <button type="submit" class="btn btn-success shadow-sm mr-2"><i class="fas fa-search mr-1"></i> Tampilkan</button>
            
            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle shadow-sm" type="button" id="dropdownMenuButton" data-toggle="dropdown">
                    <i class="fas fa-download mr-1"></i> Export
                </button>
                <div class="dropdown-menu">
                    <a class="dropdown-item" target="_blank" href="<?= base_url("laporan/cetak-arus-kas?bulan=$filter_bln&tahun=$filter_thn") ?>">
                        <i class="fas fa-file-pdf text-danger mr-2"></i> Cetak PDF
                    </a>
                    <a class="dropdown-item" target="_blank" href="<?= base_url("laporan/export-arus-kas?bulan=$filter_bln&tahun=$filter_thn") ?>">
                        <i class="fas fa-file-excel text-success mr-2"></i> Export Excel
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-lg mb-4">
    <div class="card-body p-5">
        
        <div class="text-center mb-5">
            <h4 class="font-weight-bold text-uppercase text-gray-900 mb-1">SISTEM INFORMASI AKUNTANSI</h4>
            <h5 class="font-weight-bold text-gray-800">LAPORAN ARUS KAS (CASH FLOW)</h5>
            <p class="text-gray-600">Periode <?= date('F Y', mktime(0, 0, 0, $filter_bln, 1, $filter_thn)) ?></p>
            <hr class="border-dark mt-4">
        </div>

        <div class="table-responsive">
            <table class="table table-borderless table-hover">
                
                <!-- SALDO AWAL -->
                <tr class="bg-gray-200">
                    <th class="text-uppercase pl-3">Saldo Kas Awal</th>
                    <th class="text-right pr-3 font-weight-bold">Rp <?= number_format($saldo_awal, 0, ',', '.') ?></th>
                </tr>

                <!-- ARUS KAS MASUK -->
                <tr><td colspan="2" class="text-success font-weight-bold pt-4 pl-3 text-uppercase">Arus Kas Masuk (Penerimaan)</td></tr>
                <?php 
                $total_masuk = 0;
                foreach($arus_masuk as $m): 
                    $total_masuk += $m['debit'];
                ?>
                <tr>
                    <td class="pl-4">
                        <?= date('d/m', strtotime($m['tgl_jurnal'])) ?> - <?= $m['keterangan'] ?> 
                        <span class="badge badge-light text-muted small"><?= $m['nama_akun'] ?></span>
                    </td>
                    <td class="text-right text-gray-700">Rp <?= number_format($m['debit'], 0, ',', '.') ?></td>
                </tr>
                <?php endforeach; ?>
                <tr class="border-top">
                    <td class="pl-4 font-weight-bold font-italic">Total Penerimaan Kas</td>
                    <td class="text-right font-weight-bold text-success">Rp <?= number_format($total_masuk, 0, ',', '.') ?></td>
                </tr>

                <!-- ARUS KAS KELUAR -->
                <tr><td colspan="2" class="text-danger font-weight-bold pt-4 pl-3 text-uppercase">Arus Kas Keluar (Pengeluaran)</td></tr>
                <?php 
                $total_keluar = 0;
                foreach($arus_keluar as $k): 
                    $total_keluar += $k['kredit'];
                ?>
                <tr>
                    <td class="pl-4">
                        <?= date('d/m', strtotime($k['tgl_jurnal'])) ?> - <?= $k['keterangan'] ?>
                        <span class="badge badge-light text-muted small"><?= $k['nama_akun'] ?></span>
                    </td>
                    <td class="text-right text-gray-700">(Rp <?= number_format($k['kredit'], 0, ',', '.') ?>)</td>
                </tr>
                <?php endforeach; ?>
                <tr class="border-top">
                    <td class="pl-4 font-weight-bold font-italic">Total Pengeluaran Kas</td>
                    <td class="text-right font-weight-bold text-danger">(Rp <?= number_format($total_keluar, 0, ',', '.') ?>)</td>
                </tr>

                <!-- KENAIKAN/PENURUNAN BERSIH -->
                <?php $kenaikan_bersih = $total_masuk - $total_keluar; ?>
                <tr class="bg-gray-100 mt-3">
                    <td class="pl-3 font-weight-bold">Kenaikan / (Penurunan) Kas Bersih</td>
                    <td class="text-right font-weight-bold <?= $kenaikan_bersih >= 0 ? 'text-success' : 'text-danger' ?>">
                        Rp <?= number_format($kenaikan_bersih, 0, ',', '.') ?>
                    </td>
                </tr>

                <!-- SALDO AKHIR -->
                <tfoot class="bg-success text-white">
                    <tr style="font-size: 1.2em;">
                        <th class="text-uppercase pl-3 py-3">Saldo Kas Akhir</th>
                        <th class="text-right py-3 pr-3">
                            Rp <?= number_format($saldo_awal + $kenaikan_bersih, 0, ',', '.') ?>
                        </th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>