<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<style>
    .filter-box { background: #fff; border-radius: 8px; box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15); border-left: 4px solid #4e73df; }
    .table-ledger thead th { background-color: #2c3e50; color: white; text-transform: uppercase; font-size: 0.85rem; letter-spacing: 0.05em; }
    .table-ledger tbody tr:hover { background-color: #f8f9fc; }
    .font-mono { font-family: 'Consolas', monospace; font-weight: bold; }
    
    /* Style Tombol Navigasi Bulat */
    .btn-nav-circle {
        display: inline-block;
        width: 35px; height: 35px; border-radius: 50%; padding: 0; line-height: 33px; text-align: center;
        background: #f8f9fc; border: 1px solid #d1d3e2; color: #4e73df; transition: all 0.2s;
        text-decoration: none;
    }
    .btn-nav-circle:hover { background: #4e73df; color: white; text-decoration: none; border-color: #4e73df; }
    .btn-nav-circle.disabled { opacity: 0.5; cursor: not-allowed; pointer-events: none; background: #eaecf4; color: #858796; }
</style>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Buku Besar (General Ledger)</h1>
</div>

<!-- 1. AREA FILTER -->
<div class="filter-box p-4 mb-4">
    <form action="" method="get">
        <div class="row align-items-end">
            <div class="col-md-4 mb-3 mb-md-0">
                <label class="small font-weight-bold text-gray-600">Pilih Akun</label>
                <!-- Onchange submit agar saat pilih dropdown langsung loading -->
                <select name="akun" class="form-control" required onchange="this.form.submit()">
                    <option value="">-- Cari Kode / Nama Akun --</option>
                    <?php foreach($list_akun as $row): ?>
                        <option value="<?= $row['kode_akun'] ?>" <?= ($filter_akun == $row['kode_akun']) ? 'selected' : '' ?>>
                            <?= $row['kode_akun'] ?> - <?= $row['nama_akun'] ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="col-md-2 mb-3 mb-md-0">
                <label class="small font-weight-bold text-gray-600">Bulan</label>
                <select name="bulan" class="form-control">
                    <?php for($m=1; $m<=12; $m++): ?>
                        <option value="<?= $m ?>" <?= ($filter_bln == $m) ? 'selected' : '' ?>><?= date('F', mktime(0, 0, 0, $m, 10)) ?></option>
                    <?php endfor; ?>
                </select>
            </div>

            <div class="col-md-2 mb-3 mb-md-0">
                <label class="small font-weight-bold text-gray-600">Tahun</label>
                <input type="number" name="tahun" class="form-control" value="<?= $filter_thn ?>">
            </div>

            <div class="col-md-4 d-flex">
                <button type="submit" class="btn btn-primary btn-block mr-2 shadow-sm">
                    <i class="fas fa-search mr-1"></i> Tampilkan
                </button>
                
                <?php if($filter_akun): ?>
                    <div class="dropdown">
                        <button class="btn btn-secondary dropdown-toggle shadow-sm" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-download mr-1"></i> Export
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" target="_blank" href="<?= base_url("laporan/cetak-buku-besar?akun=$filter_akun&bulan=$filter_bln&tahun=$filter_thn") ?>">
                                <i class="fas fa-file-pdf text-danger mr-2"></i> Cetak PDF
                            </a>
                            <a class="dropdown-item" target="_blank" href="<?= base_url("laporan/export-buku-besar?akun=$filter_akun&bulan=$filter_bln&tahun=$filter_thn") ?>">
                                <i class="fas fa-file-excel text-success mr-2"></i> Export Excel
                            </a>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </form>
</div>

<?php if($akun): ?>
    
    <!-- 2. CARD HEADER INFORMASI AKUN & NAVIGASI -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 bg-white d-flex flex-row align-items-center justify-content-between">
            <div class="d-flex align-items-center">
                
                <!-- TOMBOL NAVIGASI KIRI (PREV) -->
                <!-- Menggunakan variabel $prev_akun dari Controller -->
                <a href="<?= isset($prev_akun) ? base_url("laporan/buku-besar?akun=$prev_akun&bulan=$filter_bln&tahun=$filter_thn") : '#' ?>" 
                   class="btn-nav-circle mr-3 shadow-sm <?= !isset($prev_akun) ? 'disabled' : '' ?>" title="Akun Sebelumnya">
                    <i class="fas fa-chevron-left"></i>
                </a>

                <div>
                    <h5 class="m-0 font-weight-bold text-primary"><?= $akun['nama_akun'] ?></h5>
                    <div class="mt-1">
                        <span class="badge badge-secondary mr-1">Kode: <?= $akun['kode_akun'] ?></span>
                        <span class="badge badge-info">Saldo Normal: <?= $akun['posisi_saldo_normal'] == 'D' ? 'Debit' : 'Kredit' ?></span>
                    </div>
                </div>

                <!-- TOMBOL NAVIGASI KANAN (NEXT) -->
                <!-- Menggunakan variabel $next_akun dari Controller -->
                <a href="<?= isset($next_akun) ? base_url("laporan/buku-besar?akun=$next_akun&bulan=$filter_bln&tahun=$filter_thn") : '#' ?>" 
                   class="btn-nav-circle ml-3 shadow-sm <?= !isset($next_akun) ? 'disabled' : '' ?>" title="Akun Selanjutnya">
                    <i class="fas fa-chevron-right"></i>
                </a>

            </div>
            
            <div class="text-right">
                <small class="text-uppercase text-gray-500 font-weight-bold">Saldo Akhir</small>
                <?php 
                    $saldo_sementara = 0;
                    foreach($transaksi as $t) {
                        if ($akun['posisi_saldo_normal'] == 'D') {
                            $saldo_sementara += ($t['debit'] - $t['kredit']);
                        } else {
                            $saldo_sementara += ($t['kredit'] - $t['debit']);
                        }
                    }
                ?>
                <h3 class="font-weight-bold <?= $saldo_sementara >= 0 ? 'text-success' : 'text-danger' ?>">
                    Rp <?= number_format($saldo_sementara, 0, ',', '.') ?>
                </h3>
            </div>
        </div>

        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-ledger table-striped mb-0">
                    <thead>
                        <tr>
                            <th width="12%" class="text-center">Tanggal</th>
                            <th width="12%" class="text-center">No. Bukti</th>
                            <th>Keterangan Transaksi</th>
                            <th width="15%" class="text-right">Debit</th>
                            <th width="15%" class="text-right">Kredit</th>
                            <th width="15%" class="text-right">Saldo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="bg-light text-gray-500 font-italic">
                            <td class="text-center">-</td>
                            <td class="text-center">-</td>
                            <td>Saldo Awal (Bulan Lalu)</td>
                            <td class="text-right">-</td>
                            <td class="text-right">-</td>
                            <td class="text-right font-weight-bold">Rp 0</td>
                        </tr>

                        <?php 
                        $saldo = 0;
                        $total_debit = 0;
                        $total_kredit = 0;

                        foreach($transaksi as $t): 
                            $total_debit += $t['debit'];
                            $total_kredit += $t['kredit'];

                            if ($akun['posisi_saldo_normal'] == 'D') {
                                $saldo += ($t['debit'] - $t['kredit']);
                            } else {
                                $saldo += ($t['kredit'] - $t['debit']);
                            }
                        ?>
                        <tr>
                            <td class="text-center font-weight-bold text-gray-600">
                                <?= date('d/m/Y', strtotime($t['tgl_jurnal'])) ?>
                            </td>
                            
                            <!-- FITUR DRILL-DOWN: NO BUKTI BISA DIKLIK -->
                            <!-- Menggunakan empty() untuk cek aman id_jurnal -->
                            <td class="text-center">
                                <?php if(!empty($t['id_jurnal'])): ?>
                                    <a href="<?= base_url('transaksi/detail/'.$t['id_jurnal']) ?>" target="_blank" class="badge badge-primary px-2 py-1" title="Lihat Detail Transaksi">
                                        <?= $t['no_bukti'] ?> <i class="fas fa-external-link-alt fa-xs ml-1"></i>
                                    </a>
                                <?php else: ?>
                                    <span class="badge badge-secondary"><?= $t['no_bukti'] ?></span>
                                <?php endif; ?>
                            </td>

                            <td><?= $t['keterangan'] ?></td>
                            <td class="text-right text-gray-800">
                                <?= $t['debit'] > 0 ? number_format($t['debit'], 0, ',', '.') : '-' ?>
                            </td>
                            <td class="text-right text-gray-800">
                                <?= $t['kredit'] > 0 ? number_format($t['kredit'], 0, ',', '.') : '-' ?>
                            </td>
                            <td class="text-right font-mono <?= $saldo < 0 ? 'text-danger' : 'text-primary' ?>">
                                <?= number_format($saldo, 0, ',', '.') ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>

                        <?php if(empty($transaksi)): ?>
                            <tr><td colspan="6" class="text-center py-5 text-gray-500">Tidak ada mutasi transaksi pada periode ini.</td></tr>
                        <?php endif; ?>
                    </tbody>
                    <tfoot class="bg-gray-100">
                        <tr class="font-weight-bold">
                            <td colspan="3" class="text-right text-uppercase">Total Mutasi Bulan Ini</td>
                            <td class="text-right text-success">Rp <?= number_format($total_debit, 0, ',', '.') ?></td>
                            <td class="text-right text-success">Rp <?= number_format($total_kredit, 0, ',', '.') ?></td>
                            <td class="text-right bg-primary text-white">Rp <?= number_format($saldo, 0, ',', '.') ?></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>

<?php elseif($filter_akun): ?>
    <div class="text-center py-5">
        <h4 class="text-gray-500">Akun tidak ditemukan.</h4>
    </div>
<?php else: ?>
    <div class="row justify-content-center mt-5">
        <div class="col-md-6 text-center">
            <img src="https://startbootstrap.github.io/startbootstrap-sb-admin-2/img/undraw_searching.svg" class="img-fluid mb-4" style="width: 200px;">
            <h5 class="text-gray-600">Silakan pilih Akun dan Periode di atas.</h5>
        </div>
    </div>
<?php endif; ?>

<?= $this->endSection(); ?>