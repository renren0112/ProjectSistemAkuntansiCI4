<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Buku Besar - <?= $akun['nama_akun'] ?></title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; font-size: 13px; margin: 0; padding: 20px; background: #eef1f5; }
        
        /* Container Kertas A4 */
        .page-container {
            max-width: 800px; margin: 0 auto; background: white; padding: 40px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1); border-top: 5px solid #4e73df; /* Aksen Biru */
        }

        /* Navigasi Preview */
        .preview-nav {
            max-width: 800px; margin: 0 auto 20px auto; text-align: right; background: #333; padding: 10px; border-radius: 5px; color: white; display: flex; justify-content: space-between; align-items: center;
        }
        .btn { padding: 6px 15px; border: none; border-radius: 4px; cursor: pointer; font-weight: bold; text-decoration: none; font-size: 12px; }
        .btn-print { background: #fff; color: #333; }
        .btn-close { background: #e74a3b; color: white; margin-left: 10px; }

        /* Header Laporan */
        .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 15px; }
        .company-name { font-size: 20px; font-weight: bold; color: #333; text-transform: uppercase; margin: 0; }
        .doc-title { font-size: 18px; font-weight: bold; color: #4e73df; text-transform: uppercase; margin: 5px 0; }
        
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 8px 10px; border: 1px solid #ddd; }
        th { background-color: #f8f9fc; text-align: center; font-weight: bold; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .font-bold { font-weight: bold; }
        
        /* Meta Info Akun */
        .meta-table { width: 100%; border: none; margin-bottom: 10px; }
        .meta-table td { border: none; padding: 3px 0; }

        /* Tanda Tangan */
        .signature { margin-top: 60px; display: flex; justify-content: flex-end; text-align: center; }
        .sig-box { width: 30%; }
        .sig-line { border-top: 1px solid #333; margin-top: 60px; padding-top: 5px; font-weight: bold; }

        @media print {
            body { background: white; padding: 0; }
            .page-container { box-shadow: none; border: none; margin: 0; width: 100%; max-width: 100%; padding: 0; }
            .preview-nav { display: none !important; }
        }
    </style>
</head>
<body onload="window.print()">

    <!-- Tombol Navigasi (Hilang saat Export Excel / Print) -->
    <?php if(!isset($is_excel) || !$is_excel): ?>
    <div class="preview-nav">
        <span>Mode Preview Cetak</span>
        <div>
            <button onclick="window.print()" class="btn btn-print">🖨️ Cetak / PDF</button>
            <button onclick="window.close()" class="btn btn-close">❌ Tutup</button>
        </div>
    </div>
    <?php endif; ?>

    <div class="page-container">
        <div class="header">
            <h1 class="company-name">PRIMA COMPUTINDO</h1>
            <p style="margin:5px 0; font-size:11px; color:#666;">Jl. Teknologi No. 10, Jakarta Pusat | Telp: 021-99887766</p>
            <h2 class="doc-title">LAPORAN BUKU BESAR PEMBANTU</h2>
        </div>

        <table class="meta-table">
            <tr>
                <td width="15%" class="font-bold">Kode Akun</td>
                <td width="2%">:</td>
                <td width="33%"><?= $akun['kode_akun'] ?></td>
                <td width="15%" class="font-bold">Periode</td>
                <td width="2%">:</td>
                <td><?= date('F', mktime(0,0,0,$filter_bln,10)) ?> <?= $filter_thn ?></td>
            </tr>
            <tr>
                <td class="font-bold">Nama Akun</td>
                <td>:</td>
                <td><?= $akun['nama_akun'] ?></td>
                <td class="font-bold">Saldo Normal</td>
                <td>:</td>
                <td><?= $akun['posisi_saldo_normal'] == 'D' ? 'Debit' : 'Kredit' ?></td>
            </tr>
        </table>

        <table>
            <thead>
                <tr>
                    <th width="12%">Tanggal</th>
                    <th width="12%">No Bukti</th>
                    <th>Keterangan</th>
                    <th width="15%">Debit</th>
                    <th width="15%">Kredit</th>
                    <th width="15%">Saldo</th>
                </tr>
            </thead>
            <tbody>
                <!-- Baris Saldo Awal (Placeholder) -->
                <tr style="font-style: italic; color: #666;">
                    <td class="text-center">-</td>
                    <td class="text-center">-</td>
                    <td>Saldo Awal</td>
                    <td class="text-right">-</td>
                    <td class="text-right">-</td>
                    <td class="text-right font-bold">Rp 0</td>
                </tr>

                <?php 
                $saldo = 0;
                $total_debit = 0;
                $total_kredit = 0;

                foreach($transaksi as $t): 
                    $total_debit += $t['debit'];
                    $total_kredit += $t['kredit'];

                    if ($akun['posisi_saldo_normal'] == 'D') {
                        $saldo += ($t['debit'] - $t['kredit']);
                    } else {
                        $saldo += ($t['kredit'] - $t['debit']);
                    }
                ?>
                <tr>
                    <td class="text-center"><?= date('d/m/Y', strtotime($t['tgl_jurnal'])) ?></td>
                    <td class="text-center"><?= $t['no_bukti'] ?></td>
                    <td><?= $t['keterangan'] ?></td>
                    <td class="text-right"><?= $t['debit'] > 0 ? number_format($t['debit'], 0, ',', '.') : '-' ?></td>
                    <td class="text-right"><?= $t['kredit'] > 0 ? number_format($t['kredit'], 0, ',', '.') : '-' ?></td>
                    <td class="text-right font-bold"><?= number_format($saldo, 0, ',', '.') ?></td>
                </tr>
                <?php endforeach; ?>
                
                <?php if(empty($transaksi)): ?>
                    <tr><td colspan="6" class="text-center" style="padding: 20px;">Tidak ada mutasi transaksi pada periode ini.</td></tr>
                <?php endif; ?>
            </tbody>
            <tfoot>
                <tr style="background-color: #f8f9fc;">
                    <td colspan="3" class="text-right font-bold">TOTAL MUTASI</td>
                    <td class="text-right font-bold">Rp <?= number_format($total_debit, 0, ',', '.') ?></td>
                    <td class="text-right font-bold">Rp <?= number_format($total_kredit, 0, ',', '.') ?></td>
                    <td class="text-right font-bold" style="background-color: #e3e6f0;">Rp <?= number_format($saldo, 0, ',', '.') ?></td>
                </tr>
            </tfoot>
        </table>

        <div class="signature">
            <div class="sig-box">
                <p>Jakarta, <?= date('d F Y') ?></p>
                <p>Disetujui Oleh,</p>
                <div class="sig-line">( Accounting Manager )</div>
            </div>
        </div>
    </div>

</body>
</html>