<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laba Rugi - <?= $filter_thn ?></title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; font-size: 12px; }
        .header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #000; padding-bottom: 10px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { padding: 5px; }
        .text-right { text-align: right; }
        .font-bold { font-weight: bold; }
        .section-header { background-color: #f0f0f0; text-transform: uppercase; font-weight: bold; }
        .total-row { border-top: 1px solid #000; font-weight: bold; }
        .grand-total { background-color: #ddd; font-size: 14px; font-weight: bold; border-top: 2px solid #000; border-bottom: 2px double #000; }
        
        /* Tombol Navigasi Preview */
        .preview-nav { text-align: right; margin-bottom: 20px; background: #eee; padding: 10px; border-radius: 5px; }
        .btn { padding: 6px 12px; border: none; border-radius: 4px; cursor: pointer; font-weight: bold; }
        .btn-print { background: #4e73df; color: white; }
        .btn-close { background: #e74a3b; color: white; margin-left: 5px; }

        @media print { .preview-nav { display: none; } }
    </style>
</head>
<body onload="window.print()">
    
    <!-- Tombol Preview -->
    <div class="preview-nav">
        <button onclick="window.print()" class="btn btn-print">🖨️ Cetak</button>
        <button onclick="window.close()" class="btn btn-close">❌ Tutup</button>
    </div>

    <div class="header">
        <h2 style="margin:0; text-transform:uppercase;">PRIMA COMPUTINDO</h2>
        <p style="margin:0">Jl. Teknologi No. 10, Jakarta Pusat</p>
        <h4 style="margin:10px 0">LAPORAN LABA RUGI</h4>
        <p style="margin:0">Periode: <?= date('F Y', mktime(0,0,0,$filter_bln, 1, $filter_thn)) ?></p>
    </div>

    <table>
        <!-- PENJUALAN -->
        <tr class="section-header"><td colspan="2">I. PENDAPATAN PENJUALAN</td></tr>
        <?php 
        $total_penjualan = 0;
        foreach($penjualan as $p): 
            $saldo = $p['total_kredit'] - $p['total_debit'];
            $total_penjualan += $saldo;
        ?>
        <tr>
            <td style="padding-left: 20px;"><?= $p['nama_akun'] ?></td>
            <td class="text-right"><?= number_format($saldo, 0, ',', '.') ?></td>
        </tr>
        <?php endforeach; ?>
        <tr class="total-row">
            <td style="padding-left: 20px;">Total Penjualan</td>
            <td class="text-right"><?= number_format($total_penjualan, 0, ',', '.') ?></td>
        </tr>
        
        <tr><td colspan="2">&nbsp;</td></tr>

        <!-- HPP -->
        <tr class="section-header"><td colspan="2">II. HARGA POKOK PENJUALAN</td></tr>
        <?php 
        $total_pembelian = 0;
        foreach($pembelian as $pb): 
            $saldo = $pb['total_debit'] - $pb['total_kredit'];
            $total_pembelian += $saldo;
        ?>
        <tr>
            <td style="padding-left: 20px;"><?= $pb['nama_akun'] ?></td>
            <td class="text-right">(<?= number_format($saldo, 0, ',', '.') ?>)</td>
        </tr>
        <?php endforeach; ?>
        <tr class="total-row">
            <td style="padding-left: 20px;">Total HPP</td>
            <td class="text-right">(<?= number_format($total_pembelian, 0, ',', '.') ?>)</td>
        </tr>

        <!-- LABA KOTOR -->
        <?php $laba_kotor = $total_penjualan - $total_pembelian; ?>
        <tr class="total-row" style="background:#eee;">
            <td class="font-bold">LABA KOTOR</td>
            <td class="text-right font-bold"><?= number_format($laba_kotor, 0, ',', '.') ?></td>
        </tr>

        <tr><td colspan="2">&nbsp;</td></tr>

        <!-- BEBAN -->
        <tr class="section-header"><td colspan="2">III. BEBAN OPERASIONAL</td></tr>
        <?php 
        $total_beban = 0;
        foreach($beban as $b): 
            $saldo = $b['total_debit'] - $b['total_kredit'];
            $total_beban += $saldo;
        ?>
        <tr>
            <td style="padding-left: 20px;"><?= $b['nama_akun'] ?></td>
            <td class="text-right">(<?= number_format($saldo, 0, ',', '.') ?>)</td>
        </tr>
        <?php endforeach; ?>
        <tr class="total-row">
            <td style="padding-left: 20px;">Total Beban</td>
            <td class="text-right">(<?= number_format($total_beban, 0, ',', '.') ?>)</td>
        </tr>

        <!-- PENDAPATAN LAIN -->
        <?php $total_lain = 0;
        if(!empty($pendapatan_lain)): ?>
            <tr><td colspan="2">&nbsp;</td></tr>
            <tr class="section-header"><td colspan="2">IV. PENDAPATAN LAIN-LAIN</td></tr>
            <?php foreach($pendapatan_lain as $pl): 
                $saldo = $pl['total_kredit'] - $pl['total_debit'];
                $total_lain += $saldo;
            ?>
            <tr>
                <td style="padding-left: 20px;"><?= $pl['nama_akun'] ?></td>
                <td class="text-right"><?= number_format($saldo, 0, ',', '.') ?></td>
            </tr>
            <?php endforeach; endif; ?>

        <tr><td colspan="2">&nbsp;</td></tr>

        <!-- LABA BERSIH -->
        <?php $laba_bersih = $laba_kotor - $total_beban + $total_lain; ?>
        <tr class="grand-total">
            <td style="padding: 10px;">LABA BERSIH</td>
            <td class="text-right" style="padding: 10px;">Rp <?= number_format($laba_bersih, 0, ',', '.') ?></td>
        </tr>
    </table>
    
    <div style="margin-top: 50px; text-align: center; width: 30%; float: right;">
        <p>Disetujui Oleh,</p>
        <br><br><br>
        <p style="border-top: 1px solid #000; font-weight: bold;">( Manajer Keuangan )</p>
    </div>
</body>
</html>