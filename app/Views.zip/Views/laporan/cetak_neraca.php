<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Neraca Saldo - <?= $tahun ?></title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; font-size: 13px; margin: 0; padding: 20px; background: #eef1f5; }
        
        /* Container Kertas A4 */
        .page-container {
            max-width: 800px; margin: 0 auto; background: white; padding: 40px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1); border-top: 5px solid #4e73df; /* Aksen Biru */
        }

        /* Navigasi Preview */
        .preview-nav {
            max-width: 800px; margin: 0 auto 20px auto; text-align: right; background: #333; padding: 10px; border-radius: 5px; color: white; display: flex; justify-content: space-between; align-items: center;
        }
        .btn { padding: 6px 15px; border: none; border-radius: 4px; cursor: pointer; font-weight: bold; text-decoration: none; font-size: 12px; }
        .btn-print { background: #fff; color: #333; }
        .btn-close { background: #e74a3b; color: white; margin-left: 10px; }

        /* Header Laporan */
        .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 15px; }
        .company-name { font-size: 20px; font-weight: bold; color: #333; text-transform: uppercase; margin: 0; }
        .doc-title { font-size: 18px; font-weight: bold; color: #4e73df; text-transform: uppercase; margin: 5px 0; }
        
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 8px 10px; border: 1px solid #ddd; }
        th { background-color: #f8f9fc; text-align: center; font-weight: bold; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .font-bold { font-weight: bold; }
        
        /* Tanda Tangan */
        .signature { margin-top: 60px; display: flex; justify-content: flex-end; text-align: center; }
        .sig-box { width: 30%; }
        .sig-line { border-top: 1px solid #333; margin-top: 60px; padding-top: 5px; font-weight: bold; }

        @media print {
            body { background: white; padding: 0; }
            .page-container { box-shadow: none; border: none; margin: 0; width: 100%; max-width: 100%; padding: 0; }
            .preview-nav { display: none !important; }
        }
    </style>
</head>
<body onload="window.print()">

    <!-- Tombol Navigasi (Hilang saat Export Excel / Print) -->
    <?php if(!isset($is_excel) || !$is_excel): ?>
    <div class="preview-nav">
        <span>Mode Preview Cetak</span>
        <div>
            <button onclick="window.print()" class="btn btn-print">🖨️ Cetak / PDF</button>
            <button onclick="window.close()" class="btn btn-close">❌ Tutup</button>
        </div>
    </div>
    <?php endif; ?>

    <div class="page-container">
        <div class="header">
            <h1 class="company-name">PRIMA COMPUTINDO</h1>
            <p style="margin:5px 0; font-size:11px; color:#666;">Jl. Teknologi No. 10, Jakarta Pusat | Telp: 021-99887766</p>
            <h2 class="doc-title">NERACA SALDO (TRIAL BALANCE)</h2>
            <p style="margin:0; font-size:12px;">Periode Tahun: <?= $tahun ?></p>
        </div>

        <table>
            <thead>
                <tr>
                    <th width="15%">Kode Akun</th>
                    <th>Nama Akun</th>
                    <th width="20%">Debit</th>
                    <th width="20%">Kredit</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $grandTotalDebit = 0;
                $grandTotalKredit = 0;
                
                foreach($neraca as $row): 
                    $debit_trans = $row['total_debit'] ?? 0;
                    $kredit_trans = $row['total_kredit'] ?? 0;
                    
                    $saldo_debit = 0;
                    $saldo_kredit = 0;

                    if($row['posisi_saldo_normal'] == 'D') {
                        $saldo_debit = $debit_trans - $kredit_trans;
                        if($saldo_debit < 0) {
                            $saldo_kredit = abs($saldo_debit);
                            $saldo_debit = 0;
                        }
                    } else {
                        $saldo_kredit = $kredit_trans - $debit_trans;
                        if($saldo_kredit < 0) {
                            $saldo_debit = abs($saldo_kredit);
                            $saldo_kredit = 0;
                        }
                    }

                    $grandTotalDebit += $saldo_debit;
                    $grandTotalKredit += $saldo_kredit;
                ?>
                <tr>
                    <td class="text-center"><?= $row['kode_akun'] ?></td>
                    <td><?= $row['nama_akun'] ?></td>
                    <td class="text-right"><?= $saldo_debit > 0 ? number_format($saldo_debit, 0, ',', '.') : '-' ?></td>
                    <td class="text-right"><?= $saldo_kredit > 0 ? number_format($saldo_kredit, 0, ',', '.') : '-' ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr style="background-color: #f8f9fc;">
                    <td colspan="2" class="text-right font-bold">TOTAL</td>
                    <td class="text-right font-bold">Rp <?= number_format($grandTotalDebit, 0, ',', '.') ?></td>
                    <td class="text-right font-bold">Rp <?= number_format($grandTotalKredit, 0, ',', '.') ?></td>
                </tr>
                <!-- Status Balance -->
                <tr style="text-align: center; color: white; background-color: <?= ($grandTotalDebit == $grandTotalKredit) ? '#1cc88a' : '#e74a3b' ?>;">
                    <td colspan="4" class="font-bold" style="padding: 5px;">
                        STATUS: <?= ($grandTotalDebit == $grandTotalKredit) ? 'SEIMBANG (BALANCE)' : 'TIDAK SEIMBANG' ?>
                    </td>
                </tr>
            </tfoot>
        </table>

        <div class="signature">
            <div class="sig-box">
                <p>Jakarta, <?= date('d F Y') ?></p>
                <p>Disetujui Oleh,</p>
                <div class="sig-line">( Accounting Manager )</div>
            </div>
        </div>
    </div>

</body>
</html>