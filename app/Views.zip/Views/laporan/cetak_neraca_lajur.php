<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Neraca Lajur - <?= $filter_thn ?></title>
    <style>
        @page { size: landscape; margin: 10mm; }
        body { font-family: sans-serif; font-size: 10px; }
        .header { text-align: center; margin-bottom: 10px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #000; padding: 3px; }
        th { background: #eee; text-align: center; }
        .text-right { text-align: right; }
        .grand-total { background: #ddd; font-weight: bold; }
        @media print { .no-print { display: none; } }
    </style>
</head>
<body onload="window.print()">
    <div class="no-print" style="text-align: right; margin-bottom: 5px;">
        <button onclick="window.close()">Tutup</button>
    </div>
    <div class="header">
        <h3>SISTEM INFORMASI AKUNTANSI - NERACA LAJUR (WORKSHEET)</h3>
        <p>Periode: <?= date('F Y', mktime(0,0,0,$filter_bln, 1, $filter_thn)) ?></p>
    </div>
    <table>
        <thead>
            <tr>
                <th rowspan="2">Kode</th> <th rowspan="2">Nama Akun</th>
                <th colspan="2">Neraca Saldo</th> <th colspan="2">AJP</th>
                <th colspan="2">NS Disesuaikan</th> <th colspan="2">Laba Rugi</th> <th colspan="2">Neraca</th>
            </tr>
            <tr>
                <th>D</th> <th>K</th> <th>D</th> <th>K</th> <th>D</th> <th>K</th> <th>D</th> <th>K</th> <th>D</th> <th>K</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $t = array_fill(0, 10, 0);
            foreach($worksheet as $row): 
                $t[0] += $row['ns_d']; $t[1] += $row['ns_k'];
                $t[2] += $row['ajp_d']; $t[3] += $row['ajp_k'];
                $t[4] += $row['nsd_d']; $t[5] += $row['nsd_k'];
                $t[6] += $row['lr_d']; $t[7] += $row['lr_k'];
                $t[8] += $row['nr_d']; $t[9] += $row['nr_k'];
            ?>
            <tr>
                <td><?= $row['kode'] ?></td> <td><?= $row['nama'] ?></td>
                <td class="text-right"><?= $row['ns_d'] ?: '-' ?></td> <td class="text-right"><?= $row['ns_k'] ?: '-' ?></td>
                <td class="text-right"><?= $row['ajp_d'] ?: '-' ?></td> <td class="text-right"><?= $row['ajp_k'] ?: '-' ?></td>
                <td class="text-right"><?= $row['nsd_d'] ?: '-' ?></td> <td class="text-right"><?= $row['nsd_k'] ?: '-' ?></td>
                <td class="text-right"><?= $row['lr_d'] ?: '-' ?></td> <td class="text-right"><?= $row['lr_k'] ?: '-' ?></td>
                <td class="text-right"><?= $row['nr_d'] ?: '-' ?></td> <td class="text-right"><?= $row['nr_k'] ?: '-' ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr class="grand-total">
                <td colspan="2" class="text-right">TOTAL</td>
                <?php for($i=0; $i<10; $i++): ?>
                    <td class="text-right"><?= number_format($t[$i]) ?></td>
                <?php endfor; ?>
            </tr>
            <?php 
                $selisih_lr = $t[7] - $t[6];
                $laba = ($selisih_lr >= 0) ? $selisih_lr : 0;
                $rugi = ($selisih_lr < 0) ? abs($selisih_lr) : 0;
            ?>
            <tr>
                <td colspan="2" class="text-right font-bold">LABA BERSIH</td>
                <td colspan="6"></td>
                <td class="text-right"><?= $laba ? number_format($laba) : '-' ?></td>
                <td class="text-right"><?= $rugi ? number_format($rugi) : '-' ?></td>
                <td class="text-right"><?= $rugi ? number_format($rugi) : '-' ?></td>
                <td class="text-right"><?= $laba ? number_format($laba) : '-' ?></td>
            </tr>
        </tfoot>
    </table>
</body>
</html>