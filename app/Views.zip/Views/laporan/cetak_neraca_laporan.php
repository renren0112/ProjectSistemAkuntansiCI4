<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Neraca - <?= $filter_thn ?></title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; font-size: 13px; margin: 0; padding: 20px; background: #eef1f5; }
        
        /* Container Kertas A4 */
        .page-container {
            max-width: 900px; margin: 0 auto; background: white; padding: 40px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1); border-top: 5px solid #4e73df; /* Aksen Biru */
        }

        /* Navigasi Preview */
        .preview-nav {
            max-width: 900px; margin: 0 auto 20px auto; text-align: right; background: #333; padding: 10px; border-radius: 5px; color: white; display: flex; justify-content: space-between; align-items: center;
        }
        .btn { padding: 6px 15px; border: none; border-radius: 4px; cursor: pointer; font-weight: bold; text-decoration: none; font-size: 12px; }
        .btn-print { background: #fff; color: #333; }
        .btn-close { background: #e74a3b; color: white; margin-left: 10px; }

        /* Header Laporan */
        .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 15px; }
        .company-name { font-size: 20px; font-weight: bold; color: #333; text-transform: uppercase; margin: 0; }
        .doc-title { font-size: 18px; font-weight: bold; color: #4e73df; text-transform: uppercase; margin: 5px 0; }
        
        /* Layout 2 Kolom (Aset vs Pasiva) */
        .neraca-container { display: flex; width: 100%; border: 1px solid #000; }
        .column { width: 50%; padding: 0; vertical-align: top; }
        .col-left { border-right: 1px solid #000; }
        
        /* Section Title */
        .section-header { 
            background-color: #f0f0f0; 
            padding: 10px; 
            text-align: center; 
            font-weight: bold; 
            text-transform: uppercase; 
            border-bottom: 1px solid #000;
        }

        table { width: 100%; border-collapse: collapse; }
        td { padding: 5px 10px; }
        .text-right { text-align: right; }
        .font-bold { font-weight: bold; }
        .sub-header { font-weight: bold; text-decoration: underline; padding-top: 10px; padding-bottom: 5px; }

        /* Total Box */
        .total-box { 
            background-color: #ddd; 
            padding: 10px; 
            font-weight: bold; 
            border-top: 1px solid #000; 
            display: flex; 
            justify-content: space-between;
        }

        /* Tanda Tangan */
        .signature { margin-top: 60px; display: flex; justify-content: flex-end; text-align: center; }
        .sig-box { width: 30%; }
        .sig-line { border-top: 1px solid #333; margin-top: 60px; padding-top: 5px; font-weight: bold; }

        @media print {
            body { background: white; padding: 0; }
            .page-container { box-shadow: none; border: none; margin: 0; width: 100%; max-width: 100%; padding: 0; }
            .preview-nav { display: none !important; }
        }
    </style>
</head>
<body onload="window.print()">

    <!-- Tombol Navigasi -->
    <?php if(!isset($is_excel) || !$is_excel): ?>
    <div class="preview-nav">
        <span>Mode Preview Cetak</span>
        <div>
            <button onclick="window.print()" class="btn btn-print">🖨️ Cetak / PDF</button>
            <button onclick="window.close()" class="btn btn-close">❌ Tutup</button>
        </div>
    </div>
    <?php endif; ?>

    <div class="page-container">
        <div class="header">
            <h1 class="company-name">PRIMA COMPUTINDO</h1>
            <p style="margin:5px 0; font-size:11px; color:#666;">Jl. Teknologi No. 10, Jakarta Pusat | Telp: 021-99887766</p>
            <h2 class="doc-title">LAPORAN POSISI KEUANGAN (NERACA)</h2>
            <p style="margin:0; font-size:12px;">Per: <?= date('d F Y', mktime(0,0,0,$filter_bln+1, 0, $filter_thn)) ?></p>
        </div>

        <div class="neraca-container">
            <!-- KOLOM KIRI: ASET -->
            <div class="column col-left">
                <div class="section-header">ASET (AKTIVA)</div>
                
                <table>
                    <!-- Aset Lancar & Tetap digabung (bisa dipisah jika ada kategori) -->
                    <tr><td colspan="2" class="sub-header">Rincian Aset</td></tr>
                    <?php 
                    $total_aset = 0; 
                    foreach($aset as $a): 
                        $saldo = $a['total_debit'] - $a['total_kredit']; 
                        $total_aset += $saldo; 
                    ?>
                    <tr>
                        <td><?= $a['nama_akun'] ?></td>
                        <td class="text-right">Rp <?= number_format($saldo, 0, ',', '.') ?></td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <!-- Spacer agar tinggi seimbang jika data sedikit -->
                    <tr><td colspan="2" style="height: 50px;"></td></tr>
                </table>
            </div>

            <!-- KOLOM KANAN: PASIVA -->
            <div class="column">
                <div class="section-header">LIABILITAS & EKUITAS</div>
                
                <table>
                    <!-- LIABILITAS -->
                    <tr><td colspan="2" class="sub-header">Liabilitas (Kewajiban)</td></tr>
                    <?php 
                    $total_lia = 0; 
                    foreach($liabilitas as $l): 
                        $saldo = $l['total_kredit'] - $l['total_debit']; 
                        $total_lia += $saldo; 
                    ?>
                    <tr>
                        <td><?= $l['nama_akun'] ?></td>
                        <td class="text-right">Rp <?= number_format($saldo, 0, ',', '.') ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <tr style="background:#f9f9f9; font-weight:bold;">
                        <td style="padding-left:20px;">Total Liabilitas</td>
                        <td class="text-right">Rp <?= number_format($total_lia, 0, ',', '.') ?></td>
                    </tr>

                    <!-- EKUITAS -->
                    <tr><td colspan="2" class="sub-header">Ekuitas (Modal)</td></tr>
                    <?php 
                    $total_eku = 0; 
                    foreach($ekuitas as $e): 
                        if($e['posisi_saldo_normal']=='K') $saldo = $e['total_kredit'] - $e['total_debit'];
                        else $saldo = ($e['total_debit'] - $e['total_kredit']) * -1;
                        $total_eku += $saldo;
                    ?>
                    <tr>
                        <td><?= $e['nama_akun'] ?></td>
                        <td class="text-right">Rp <?= number_format($saldo, 0, ',', '.') ?></td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <!-- Laba Berjalan -->
                    <tr>
                        <td>Laba Tahun Berjalan</td>
                        <td class="text-right font-bold">Rp <?= number_format($laba_bersih, 0, ',', '.') ?></td>
                    </tr>
                    
                    <tr style="background:#f9f9f9; font-weight:bold;">
                        <td style="padding-left:20px;">Total Ekuitas</td>
                        <td class="text-right">Rp <?= number_format($total_eku + $laba_bersih, 0, ',', '.') ?></td>
                    </tr>
                </table>
            </div>
        </div>

        <!-- TOTAL BAWAH -->
        <div class="neraca-container" style="border-top: none;">
            <div class="column col-left">
                <div class="total-box">
                    <span>TOTAL ASET</span>
                    <span>Rp <?= number_format($total_aset, 0, ',', '.') ?></span>
                </div>
            </div>
            <div class="column">
                <div class="total-box">
                    <span>TOTAL LIABILITAS & EKUITAS</span>
                    <span>Rp <?= number_format($total_lia + $total_eku + $laba_bersih, 0, ',', '.') ?></span>
                </div>
            </div>
        </div>

        <div class="signature">
            <div class="sig-box">
                <p>Jakarta, <?= date('d F Y') ?></p>
                <p>Disetujui Oleh,</p>
                <div class="sig-line">( Pimpinan Perusahaan )</div>
            </div>
        </div>
    </div>

</body>
</html>