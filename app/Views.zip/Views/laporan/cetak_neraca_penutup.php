<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Neraca Saldo Penutup - <?= $filter_thn ?></title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; font-size: 12px; }
        .header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #000; padding-bottom: 10px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { padding: 5px; border: 1px solid #000; }
        th { background-color: #f0f0f0; text-align: center; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .font-bold { font-weight: bold; }
        .grand-total { background-color: #ddd; font-weight: bold; }
        @media print { .no-print { display: none; } }
    </style>
</head>
<body onload="window.print()">
    
    <!-- Tombol Tutup (Hanya tampil di layar) -->
    <div class="no-print" style="text-align: right; margin-bottom: 10px;">
        <button onclick="window.close()" style="cursor: pointer; padding: 5px 10px;">Tutup</button>
    </div>

    <div class="header">
        <h3 style="margin:0">SISTEM INFORMASI AKUNTANSI</h3>
        <h4 style="margin:5px 0">NERACA SALDO SETELAH PENUTUPAN</h4>
        <p style="margin:0">Periode: <?= date('F Y', mktime(0,0,0,$filter_bln, 1, $filter_thn)) ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th width="15%">Kode Akun</th>
                <th>Nama Akun</th>
                <th width="20%">Debit</th>
                <th width="20%">Kredit</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $grandTotalDebit = 0; 
            $grandTotalKredit = 0;
            
            foreach($neraca as $row): 
                $saldo_debit = 0; 
                $saldo_kredit = 0;

                if($row['posisi_saldo_normal'] == 'D') {
                    $saldo_debit = $row['total_debit'] - $row['total_kredit'];
                    if($saldo_debit < 0) { 
                        $saldo_kredit = abs($saldo_debit); 
                        $saldo_debit = 0; 
                    }
                } else {
                    $saldo_kredit = $row['total_kredit'] - $row['total_debit'];
                    if($saldo_kredit < 0) { 
                        $saldo_debit = abs($saldo_kredit); 
                        $saldo_kredit = 0; 
                    }
                }

                // Sembunyikan akun saldo 0 (Akun Nominal yang sudah ditutup)
                if ($saldo_debit == 0 && $saldo_kredit == 0) continue;

                $grandTotalDebit += $saldo_debit;
                $grandTotalKredit += $saldo_kredit;
            ?>
            <tr>
                <td class="text-center"><?= $row['kode_akun'] ?></td>
                <td><?= $row['nama_akun'] ?></td>
                <td class="text-right"><?= $saldo_debit > 0 ? number_format($saldo_debit, 0, ',', '.') : '-' ?></td>
                <td class="text-right"><?= $saldo_kredit > 0 ? number_format($saldo_kredit, 0, ',', '.') : '-' ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr class="grand-total">
                <td colspan="2" class="text-right text-uppercase">TOTAL AKHIR</td>
                <td class="text-right">Rp <?= number_format($grandTotalDebit, 0, ',', '.') ?></td>
                <td class="text-right">Rp <?= number_format($grandTotalKredit, 0, ',', '.') ?></td>
            </tr>
        </tfoot>
    </table>

</body>
</html>