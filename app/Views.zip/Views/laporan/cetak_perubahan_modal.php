<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Perubahan Modal - <?= $filter_thn ?></title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; font-size: 12px; margin: 0; padding: 20px; background: #eef1f5; }
        
        /* Container Kertas A4 */
        .page-container {
            max-width: 800px; margin: 0 auto; background: white; padding: 40px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1); border-top: 5px solid #f6c23e; /* Aksen Kuning/Warning */
        }

        /* Navigasi Preview */
        .preview-nav {
            max-width: 800px; margin: 0 auto 20px auto; text-align: right; background: #333; padding: 10px; border-radius: 5px; color: white; display: flex; justify-content: space-between; align-items: center;
        }
        .btn { padding: 6px 15px; border: none; border-radius: 4px; cursor: pointer; font-weight: bold; text-decoration: none; font-size: 12px; }
        .btn-print { background: #fff; color: #333; }
        .btn-close { background: #e74a3b; color: white; margin-left: 10px; }

        /* Header Laporan */
        .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 15px; }
        .company-name { font-size: 20px; font-weight: bold; color: #333; text-transform: uppercase; margin: 0; }
        .doc-title { font-size: 18px; font-weight: bold; color: #f6c23e; text-transform: uppercase; margin: 5px 0; }
        
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        td { padding: 8px 10px; border-bottom: 1px dashed #eee; }
        .text-right { text-align: right; }
        .font-bold { font-weight: bold; }
        
        .grand-total { background-color: #f6c23e; color: #fff; font-size: 14px; font-weight: bold; border-top: 2px solid #333; }
        .sub-total { background-color: #fcf8e3; font-weight: bold; border-top: 1px solid #333; }

        /* Tanda Tangan */
        .signature { margin-top: 60px; display: flex; justify-content: flex-end; text-align: center; }
        .sig-box { width: 30%; }
        .sig-line { border-top: 1px solid #333; margin-top: 60px; padding-top: 5px; font-weight: bold; }

        @media print {
            body { background: white; padding: 0; }
            .page-container { box-shadow: none; border: none; margin: 0; width: 100%; max-width: 100%; padding: 0; }
            .preview-nav { display: none !important; }
        }
    </style>
</head>
<body onload="window.print()">
    
    <!-- Tombol Preview -->
    <div class="preview-nav">
        <span>Mode Preview Cetak</span>
        <div>
            <button onclick="window.print()" class="btn btn-print">🖨️ Cetak / PDF</button>
            <button onclick="window.close()" class="btn btn-close">❌ Tutup</button>
        </div>
    </div>

    <div class="page-container">
        
        <div class="header">
            <h1 class="company-name">PRIMA COMPUTINDO</h1>
            <p style="margin:5px 0; font-size:11px; color:#666;">Jl. Teknologi No. 10, Jakarta Pusat | Telp: 021-99887766</p>
            <h2 class="doc-title">LAPORAN PERUBAHAN MODAL</h2>
            <p style="margin:0; font-size:12px;">Periode Berakhir: <?= date('d F Y', mktime(0,0,0,$filter_bln+1, 0, $filter_thn)) ?></p>
        </div>

        <table>
            <?php 
            $modal_awal = 0; $prive = 0;
            foreach($ekuitas as $e) {
                if ($e['posisi_saldo_normal'] == 'K') $modal_awal += ($e['total_kredit'] - $e['total_debit']);
                else $prive += ($e['total_debit'] - $e['total_kredit']);
            }
            ?>
            
            <!-- Modal Awal -->
            <tr>
                <td class="font-bold" style="font-size: 13px;">Modal Awal</td>
                <td class="text-right font-bold" style="font-size: 13px;">Rp <?= number_format($modal_awal, 0, ',', '.') ?></td>
            </tr>
            
            <tr><td colspan="2">&nbsp;</td></tr>

            <!-- Penambahan -->
            <tr>
                <td>Laba Bersih Tahun Berjalan</td>
                <td class="text-right">Rp <?= number_format($laba_bersih, 0, ',', '.') ?></td>
            </tr>
            
            <!-- Pengurangan -->
            <?php if($prive > 0): ?>
            <tr>
                <td>Dikurangi: Prive (Penarikan Pribadi)</td>
                <td class="text-right">(Rp <?= number_format($prive, 0, ',', '.') ?>)</td>
            </tr>
            <?php endif; ?>

            <!-- Kenaikan Bersih -->
            <tr class="sub-total">
                <td>Penambahan / (Penurunan) Modal</td>
                <td class="text-right">
                    <?php $kenaikan = $laba_bersih - $prive; ?>
                    Rp <?= number_format($kenaikan, 0, ',', '.') ?>
                </td>
            </tr>

            <tr><td colspan="2">&nbsp;</td></tr>

            <!-- Modal Akhir -->
            <tr class="grand-total">
                <td style="padding: 10px;">MODAL AKHIR</td>
                <td class="text-right" style="padding: 10px;">Rp <?= number_format($modal_awal + $kenaikan, 0, ',', '.') ?></td>
            </tr>
        </table>

        <div class="signature">
            <div class="sig-box">
                <p>Jakarta, <?= date('d F Y') ?></p>
                <p>Disetujui Oleh,</p>
                <div class="sig-line">( Pimpinan )</div>
            </div>
        </div>

    </div>

</body>
</html>