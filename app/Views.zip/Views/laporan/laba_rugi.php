<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Laporan Laba Rugi (Income Statement)</h1>
</div>

<!-- Filter -->
<div class="card shadow mb-4 border-left-primary">
    <div class="card-body py-3">
        <form action="" method="get" class="form-inline">
            <label class="mr-2 font-weight-bold">Periode:</label>
            <select name="bulan" class="form-control mr-2">
                <?php for($m=1; $m<=12; $m++): ?>
                    <option value="<?= $m ?>" <?= ($filter_bln == $m) ? 'selected' : '' ?>><?= date('F', mktime(0, 0, 0, $m, 10)) ?></option>
                <?php endfor; ?>
            </select>
            <input type="number" name="tahun" class="form-control mr-3" value="<?= $filter_thn ?>" style="width: 100px;">
            
            <button type="submit" class="btn btn-primary shadow-sm mr-2"><i class="fas fa-search mr-1"></i> Tampilkan</button>
            
            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle shadow-sm" type="button" id="dropdownMenuButton" data-toggle="dropdown">
                    <i class="fas fa-download mr-1"></i> Export
                </button>
                <div class="dropdown-menu">
                    <a class="dropdown-item" target="_blank" href="<?= base_url("laporan/cetak-laba-rugi?bulan=$filter_bln&tahun=$filter_thn") ?>">
                        <i class="fas fa-file-pdf text-danger mr-2"></i> Cetak PDF
                    </a>
                    <a class="dropdown-item" target="_blank" href="<?= base_url("laporan/export-laba-rugi?bulan=$filter_bln&tahun=$filter_thn") ?>">
                        <i class="fas fa-file-excel text-success mr-2"></i> Export Excel
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Kertas Laporan -->
<div class="card shadow-lg mb-4">
    <div class="card-body p-5">
        
        <!-- Kop Laporan -->
        <div class="text-center mb-5">
            <h4 class="font-weight-bold text-uppercase text-gray-900 mb-1">PRIMA COMPUTINDO</h4>
            <h5 class="font-weight-bold text-gray-800">LAPORAN LABA RUGI</h5>
            <p class="text-gray-600">Periode Berakhir <?= date('d F Y', mktime(0, 0, 0, $filter_bln + 1, 0, $filter_thn)) ?></p>
            <hr class="border-dark mt-4">
        </div>

        <div class="table-responsive">
            <table class="table table-borderless table-hover table-sm">
                
                <!-- 1. PENJUALAN -->
                <thead class="bg-gray-100">
                    <tr><th colspan="2" class="text-primary font-weight-bold text-uppercase pl-3">I. Pendapatan Penjualan</th></tr>
                </thead>
                <tbody>
                    <?php 
                    $total_penjualan = 0;
                    foreach($penjualan as $p): 
                        // Penjualan saldo normal Kredit
                        $saldo = $p['total_kredit'] - $p['total_debit'];
                        $total_penjualan += $saldo;
                    ?>
                    <tr>
                        <td class="pl-4 text-gray-800"><?= $p['nama_akun'] ?></td>
                        <td class="text-right text-gray-800" style="font-family: Consolas;">Rp <?= number_format($saldo, 0, ',', '.') ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <tr class="font-weight-bold border-top">
                        <td class="pl-4">Total Penjualan Bersih</td>
                        <td class="text-right text-primary" style="font-family: Consolas;">Rp <?= number_format($total_penjualan, 0, ',', '.') ?></td>
                    </tr>
                </tbody>

                <!-- 2. HPP / PEMBELIAN -->
                <thead class="bg-gray-100">
                    <tr><th colspan="2" class="text-danger font-weight-bold text-uppercase pl-3 mt-4">II. Harga Pokok Penjualan</th></tr>
                </thead>
                <tbody>
                    <?php 
                    $total_pembelian = 0;
                    foreach($pembelian as $pb): 
                        // Pembelian saldo normal Debit
                        $saldo = $pb['total_debit'] - $pb['total_kredit'];
                        $total_pembelian += $saldo;
                    ?>
                    <tr>
                        <td class="pl-4 text-gray-800"><?= $pb['nama_akun'] ?></td>
                        <td class="text-right text-gray-800" style="font-family: Consolas;">(Rp <?= number_format($saldo, 0, ',', '.') ?>)</td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <!-- Asumsi: HPP = Total Akun Pembelian (Metode Fisik Sederhana tanpa Stok Opname) -->
                    <tr class="font-weight-bold border-top">
                        <td class="pl-4">Total Harga Pokok Penjualan</td>
                        <td class="text-right text-danger" style="font-family: Consolas;">(Rp <?= number_format($total_pembelian, 0, ',', '.') ?>)</td>
                    </tr>
                </tbody>

                <!-- LABA KOTOR -->
                <?php $laba_kotor = $total_penjualan - $total_pembelian; ?>
                <tr class="bg-gray-200" style="font-size: 1.1em;">
                    <th class="pl-3 py-2 text-uppercase text-gray-900">Laba Kotor (Gross Profit)</th>
                    <th class="text-right py-2 text-gray-900" style="font-family: Consolas;">Rp <?= number_format($laba_kotor, 0, ',', '.') ?></th>
                </tr>

                <!-- 3. BEBAN OPERASIONAL -->
                <thead class="bg-gray-100">
                    <tr><th colspan="2" class="text-secondary font-weight-bold text-uppercase pl-3 mt-4">III. Beban Operasional</th></tr>
                </thead>
                <tbody>
                    <?php 
                    $total_beban = 0;
                    foreach($beban as $b): 
                        $saldo = $b['total_debit'] - $b['total_kredit'];
                        $total_beban += $saldo;
                    ?>
                    <tr>
                        <td class="pl-4 text-gray-800"><?= $b['nama_akun'] ?></td>
                        <td class="text-right text-gray-800" style="font-family: Consolas;">(Rp <?= number_format($saldo, 0, ',', '.') ?>)</td>
                    </tr>
                    <?php endforeach; ?>
                    <tr class="font-weight-bold border-top">
                        <td class="pl-4">Total Beban Operasional</td>
                        <td class="text-right text-danger" style="font-family: Consolas;">(Rp <?= number_format($total_beban, 0, ',', '.') ?>)</td>
                    </tr>
                </tbody>
                
                <!-- LABA OPERASIONAL -->
                <?php $laba_ops = $laba_kotor - $total_beban; ?>
                <tr class="border-top border-bottom bg-white font-weight-bold text-gray-800">
                    <td class="pl-4 py-2">Laba Operasional</td>
                    <td class="text-right py-2" style="font-family: Consolas;">Rp <?= number_format($laba_ops, 0, ',', '.') ?></td>
                </tr>

                <!-- 4. PENDAPATAN LAIN-LAIN -->
                <?php if(!empty($pendapatan_lain)): ?>
                <thead class="bg-gray-100">
                    <tr><th colspan="2" class="text-success font-weight-bold text-uppercase pl-3 mt-4">IV. Pendapatan & Beban Lain-lain</th></tr>
                </thead>
                <tbody>
                    <?php 
                    $total_lain = 0;
                    foreach($pendapatan_lain as $pl): 
                        $saldo = $pl['total_kredit'] - $pl['total_debit'];
                        $total_lain += $saldo;
                    ?>
                    <tr>
                        <td class="pl-4 text-gray-800"><?= $pl['nama_akun'] ?></td>
                        <td class="text-right text-gray-800" style="font-family: Consolas;">Rp <?= number_format($saldo, 0, ',', '.') ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <?php else: $total_lain = 0; endif; ?>

                <!-- LABA BERSIH AKHIR -->
                <tfoot class="bg-primary text-white mt-3">
                    <?php $laba_bersih = $laba_ops + $total_lain; ?>
                    <tr style="font-size: 1.2em;">
                        <th class="text-uppercase pl-3 py-3">Laba / (Rugi) Bersih</th>
                        <th class="text-right py-3 <?= $laba_bersih >= 0 ? 'text-white' : 'text-warning' ?>" style="font-family: Consolas;">
                            Rp <?= number_format($laba_bersih, 0, ',', '.') ?>
                        </th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>