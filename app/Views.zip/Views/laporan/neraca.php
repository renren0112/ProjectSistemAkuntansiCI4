<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Laporan Posisi Keuangan (Neraca)</h1>
</div>

<!-- Filter -->
<div class="card shadow mb-4 border-left-info">
    <div class="card-body py-3">
        <form action="" method="get" class="form-inline">
            <label class="mr-2 font-weight-bold">Periode:</label>
            <select name="bulan" class="form-control mr-2">
                <?php for($m=1; $m<=12; $m++): ?>
                    <option value="<?= $m ?>" <?= ($filter_bln == $m) ? 'selected' : '' ?>><?= date('F', mktime(0, 0, 0, $m, 10)) ?></option>
                <?php endfor; ?>
            </select>
            <input type="number" name="tahun" class="form-control mr-3" value="<?= $filter_thn ?>" style="width: 100px;">
            <button type="submit" class="btn btn-info shadow-sm mr-2"><i class="fas fa-search mr-1"></i> Tampilkan</button>
            
            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle shadow-sm" type="button" id="dropdownMenuButton" data-toggle="dropdown">
                    <i class="fas fa-download mr-1"></i> Export
                </button>
                <div class="dropdown-menu">
                    <a class="dropdown-item" target="_blank" href="<?= base_url("laporan/cetak-neraca-laporan?bulan=$filter_bln&tahun=$filter_thn") ?>"><i class="fas fa-file-pdf text-danger mr-2"></i> Cetak PDF</a>
                    <a class="dropdown-item" target="_blank" href="<?= base_url("laporan/export-neraca-laporan?bulan=$filter_bln&tahun=$filter_thn") ?>"><i class="fas fa-file-excel text-success mr-2"></i> Export Excel</a>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Kertas Laporan -->
<div class="card shadow-lg mb-4">
    <div class="card-body p-5">
        <div class="text-center mb-5">
            <h4 class="font-weight-bold text-uppercase text-gray-900 mb-1">PRIMA COMPUTINDO</h4>
            <h5 class="font-weight-bold text-gray-800">LAPORAN POSISI KEUANGAN (NERACA)</h5>
            <p class="text-gray-600">Per <?= date('d F', mktime(0, 0, 0, $filter_bln + 1, 0, $filter_thn)) ?> <?= $filter_thn ?></p>
            <hr class="border-dark mt-4">
        </div>

        <div class="row">
            <!-- KOLOM KIRI: ASET -->
            <div class="col-md-6 border-right">
                <h6 class="font-weight-bold text-uppercase text-center bg-gray-200 text-gray-800 p-2 mb-3 rounded">ASET (AKTIVA)</h6>
                
                <table class="table table-sm table-borderless table-hover">
                    <tr class="border-bottom"><th colspan="2" class="text-primary pl-3 pb-2">ASET LANCAR & TETAP</th></tr>
                    <?php 
                    $total_aset = 0;
                    foreach($aset as $a): 
                        $saldo = $a['total_debit'] - $a['total_kredit'];
                        $total_aset += $saldo;
                    ?>
                    <tr>
                        <td class="text-gray-800 pl-4"><?= $a['nama_akun'] ?></td>
                        <td class="text-right font-weight-bold text-gray-800" style="font-family: Consolas;">Rp <?= number_format($saldo, 0, ',', '.') ?></td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <!-- Spacer -->
                    <tr><td colspan="2" style="height: 20px;"></td></tr>

                    <tr class="bg-gray-100 border-top border-bottom">
                        <th class="pt-3 pb-3 text-uppercase pl-3">Total Aset</th>
                        <th class="text-right pt-3 pb-3 text-primary h5 font-weight-bold pr-3" style="font-family: Consolas;">Rp <?= number_format($total_aset, 0, ',', '.') ?></th>
                    </tr>
                </table>
            </div>

            <!-- KOLOM KANAN: LIABILITAS + EKUITAS -->
            <div class="col-md-6">
                <h6 class="font-weight-bold text-uppercase text-center bg-gray-200 text-gray-800 p-2 mb-3 rounded">KEWAJIBAN & EKUITAS</h6>
                
                <table class="table table-sm table-borderless table-hover">
                    <!-- Liabilitas -->
                    <tr class="border-bottom"><th colspan="2" class="text-danger pl-3 pb-2">LIABILITAS (KEWAJIBAN)</th></tr>
                    <?php 
                    $total_liabilitas = 0;
                    foreach($liabilitas as $l): 
                        $saldo = $l['total_kredit'] - $l['total_debit'];
                        $total_liabilitas += $saldo;
                    ?>
                    <tr>
                        <td class="text-gray-800 pl-4"><?= $l['nama_akun'] ?></td>
                        <td class="text-right font-weight-bold text-gray-800" style="font-family: Consolas;">Rp <?= number_format($saldo, 0, ',', '.') ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <tr class="bg-light">
                        <td class="pl-4 font-weight-bold small text-uppercase">Total Liabilitas</td>
                        <td class="text-right font-weight-bold text-danger pr-3" style="font-family: Consolas;">Rp <?= number_format($total_liabilitas, 0, ',', '.') ?></td>
                    </tr>

                    <!-- Spacer -->
                    <tr><td colspan="2" style="height: 20px;"></td></tr>

                    <!-- Ekuitas -->
                    <tr class="border-bottom"><th colspan="2" class="text-success pl-3 pb-2">EKUITAS (MODAL)</th></tr>
                    <?php 
                    $total_ekuitas_akun = 0;
                    foreach($ekuitas as $e): 
                        if($e['posisi_saldo_normal'] == 'K') {
                            $saldo = $e['total_kredit'] - $e['total_debit'];
                            $total_ekuitas_akun += $saldo;
                        } else {
                            $saldo = ($e['total_debit'] - $e['total_kredit']);
                            $total_ekuitas_akun -= $saldo;
                            echo "<tr><td class='text-gray-800 pl-4'>{$e['nama_akun']}</td><td class='text-right font-weight-bold text-danger' style='font-family: Consolas;'>(Rp ".number_format($saldo, 0, ',', '.').")</td></tr>";
                            continue;
                        }
                    ?>
                    <tr>
                        <td class="text-gray-800 pl-4"><?= $e['nama_akun'] ?></td>
                        <td class="text-right font-weight-bold text-gray-800" style="font-family: Consolas;">Rp <?= number_format($saldo, 0, ',', '.') ?></td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <!-- Laba Berjalan -->
                    <tr>
                        <td class="text-gray-800 pl-4">Laba Tahun Berjalan</td>
                        <td class="text-right text-success font-weight-bold" style="font-family: Consolas;">Rp <?= number_format($laba_bersih, 0, ',', '.') ?></td>
                    </tr>

                    <tr class="bg-light">
                        <td class="pl-4 font-weight-bold small text-uppercase">Total Ekuitas</td>
                        <td class="text-right font-weight-bold text-success pr-3" style="font-family: Consolas;">Rp <?= number_format($total_ekuitas_akun + $laba_bersih, 0, ',', '.') ?></td>
                    </tr>

                    <!-- Grand Total Pasiva -->
                    <tr><td colspan="2" style="height: 20px;"></td></tr>
                    <tr class="bg-gray-100 border-top border-bottom">
                        <th class="pt-3 pb-3 text-uppercase pl-3">Total Liabilitas & Ekuitas</th>
                        <?php $total_pasiva = $total_liabilitas + $total_ekuitas_akun + $laba_bersih; ?>
                        <th class="text-right pt-3 pb-3 text-info h5 font-weight-bold pr-3" style="font-family: Consolas;">Rp <?= number_format($total_pasiva, 0, ',', '.') ?></th>
                    </tr>
                </table>
            </div>
        </div>
        
        <!-- Indikator Balance -->
        <div class="mt-4 text-center">
            <?php if($total_aset == $total_pasiva): ?>
                <span class="badge badge-success px-4 py-2" style="font-size: 1em;"><i class="fas fa-check-circle mr-2"></i> SEIMBANG (BALANCE)</span>
            <?php else: ?>
                <span class="badge badge-danger px-4 py-2" style="font-size: 1em;">
                    <i class="fas fa-times-circle mr-2"></i> TIDAK SEIMBANG (Selisih: <?= number_format(abs($total_aset - $total_pasiva), 0, ',', '.') ?>)
                </span>
            <?php endif; ?>
        </div>

    </div>
</div>
<?= $this->endSection(); ?>