<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<style>
    /* Styling khusus Worksheet */
    .table-worksheet { font-size: 0.8rem; }
    .table-worksheet th { text-align: center; vertical-align: middle !important; padding: 5px; }
    .table-worksheet td { padding: 4px; vertical-align: middle; }
    .col-ns { background-color: #ffffff; }
    .col-ajp { background-color: #fff3cd; } /* Kuning muda */
    .col-nsd { background-color: #e3f2fd; } /* Biru muda */
    .col-lr { background-color: #fbecec; } /* Merah muda */
    .col-nr { background-color: #e8f5e9; } /* Hijau muda */
    .num-cell { text-align: right; font-family: 'Consolas', monospace; }
</style>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Neraca Lajur (Worksheet)</h1>
</div>

<!-- Filter -->
<div class="card shadow mb-4 border-left-info">
    <div class="card-body py-3">
        <form action="" method="get" class="form-inline">
            <label class="mr-2 font-weight-bold">Periode:</label>
            <select name="bulan" class="form-control mr-2 form-control-sm">
                <?php for($m=1; $m<=12; $m++): ?>
                    <option value="<?= $m ?>" <?= ($filter_bln == $m) ? 'selected' : '' ?>><?= date('F', mktime(0, 0, 0, $m, 10)) ?></option>
                <?php endfor; ?>
            </select>
            <input type="number" name="tahun" class="form-control mr-3 form-control-sm" value="<?= $filter_thn ?>" style="width: 80px;">
            <button type="submit" class="btn btn-info btn-sm shadow-sm mr-2"><i class="fas fa-search mr-1"></i> Tampilkan</button>
            
            <div class="dropdown">
                <button class="btn btn-secondary btn-sm dropdown-toggle shadow-sm" type="button" id="dropdownMenuButton" data-toggle="dropdown">
                    <i class="fas fa-download mr-1"></i> Export
                </button>
                <div class="dropdown-menu">
                    <a class="dropdown-item" target="_blank" href="<?= base_url("laporan/cetak-neraca-lajur?bulan=$filter_bln&tahun=$filter_thn") ?>"><i class="fas fa-file-pdf text-danger mr-2"></i> Cetak PDF</a>
                    <a class="dropdown-item" target="_blank" href="<?= base_url("laporan/export-neraca-lajur?bulan=$filter_bln&tahun=$filter_thn") ?>"><i class="fas fa-file-excel text-success mr-2"></i> Export Excel</a>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="card shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-worksheet table-hover" width="100%" cellspacing="0">
                <thead class="thead-dark">
                    <tr>
                        <th rowspan="2">Kode</th>
                        <th rowspan="2" style="min-width: 150px;">Nama Akun</th>
                        <th colspan="2" class="bg-white text-dark">Neraca Saldo</th>
                        <th colspan="2" class="bg-warning text-dark">Penyesuaian (AJP)</th>
                        <th colspan="2" class="bg-primary text-white">NS Disesuaikan</th>
                        <th colspan="2" class="bg-danger text-white">Laba Rugi</th>
                        <th colspan="2" class="bg-success text-white">Neraca</th>
                    </tr>
                    <tr>
                        <!-- Sub Header -->
                        <th class="col-ns">Debit</th> <th class="col-ns">Kredit</th>
                        <th class="col-ajp">Debit</th> <th class="col-ajp">Kredit</th>
                        <th class="col-nsd">Debit</th> <th class="col-nsd">Kredit</th>
                        <th class="col-lr">Debit</th> <th class="col-lr">Kredit</th>
                        <th class="col-nr">Debit</th> <th class="col-nr">Kredit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    // Inisialisasi Total Bawah
                    $t = array_fill(0, 10, 0); // Array 10 index untuk total tiap kolom
                    
                    foreach($worksheet as $row): 
                        // Tambahkan ke total
                        $t[0] += $row['ns_d']; $t[1] += $row['ns_k'];
                        $t[2] += $row['ajp_d']; $t[3] += $row['ajp_k'];
                        $t[4] += $row['nsd_d']; $t[5] += $row['nsd_k'];
                        $t[6] += $row['lr_d']; $t[7] += $row['lr_k'];
                        $t[8] += $row['nr_d']; $t[9] += $row['nr_k'];
                    ?>
                    <tr>
                        <td class="text-center font-weight-bold"><?= $row['kode'] ?></td>
                        <td><?= $row['nama'] ?></td>
                        
                        <td class="num-cell col-ns"><?= $row['ns_d'] ? number_format($row['ns_d']) : '-' ?></td>
                        <td class="num-cell col-ns"><?= $row['ns_k'] ? number_format($row['ns_k']) : '-' ?></td>
                        
                        <td class="num-cell col-ajp"><?= $row['ajp_d'] ? number_format($row['ajp_d']) : '-' ?></td>
                        <td class="num-cell col-ajp"><?= $row['ajp_k'] ? number_format($row['ajp_k']) : '-' ?></td>
                        
                        <td class="num-cell col-nsd"><?= $row['nsd_d'] ? number_format($row['nsd_d']) : '-' ?></td>
                        <td class="num-cell col-nsd"><?= $row['nsd_k'] ? number_format($row['nsd_k']) : '-' ?></td>
                        
                        <td class="num-cell col-lr"><?= $row['lr_d'] ? number_format($row['lr_d']) : '-' ?></td>
                        <td class="num-cell col-lr"><?= $row['lr_k'] ? number_format($row['lr_k']) : '-' ?></td>
                        
                        <td class="num-cell col-nr"><?= $row['nr_d'] ? number_format($row['nr_d']) : '-' ?></td>
                        <td class="num-cell col-nr"><?= $row['nr_k'] ? number_format($row['nr_k']) : '-' ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr class="font-weight-bold bg-secondary text-white">
                        <td colspan="2" class="text-right">TOTAL</td>
                        <!-- Loop Total Kolom -->
                        <?php for($i=0; $i<10; $i++): ?>
                            <td class="text-right"><?= number_format($t[$i]) ?></td>
                        <?php endfor; ?>
                    </tr>
                    
                    <!-- BARIS LABA/RUGI BERSIH -->
                    <?php 
                        $laba = 0; $rugi = 0;
                        $selisih_lr = $t[7] - $t[6]; // Kredit - Debit (Pendapatan - Beban)
                        if($selisih_lr >= 0) $laba = $selisih_lr; else $rugi = abs($selisih_lr);
                    ?>
                    <tr class="font-weight-bold">
                        <td colspan="2" class="text-right text-primary">LABA / (RUGI) BERSIH</td>
                        <td colspan="6"></td> <!-- Kosongkan kolom NS sampai NSD -->
                        
                        <!-- Kolom Laba Rugi (Menyeimbangkan) -->
                        <td class="text-right text-primary"><?= $laba > 0 ? number_format($laba) : '-' ?></td>
                        <td class="text-right text-danger"><?= $rugi > 0 ? number_format($rugi) : '-' ?></td>
                        
                        <!-- Kolom Neraca (Menyeimbangkan kebalikan) -->
                        <td class="text-right text-danger"><?= $rugi > 0 ? number_format($rugi) : '-' ?></td>
                        <td class="text-right text-primary"><?= $laba > 0 ? number_format($laba) : '-' ?></td>
                    </tr>

                    <!-- BALANCE CHECK -->
                    <tr class="font-weight-bold bg-dark text-white">
                        <td colspan="2" class="text-right">BALANCE AKHIR</td>
                        <td colspan="6"></td>
                        <!-- Total LR Akhir -->
                        <td class="text-right"><?= number_format($t[6] + $laba) ?></td>
                        <td class="text-right"><?= number_format($t[7] + $rugi) ?></td>
                        <!-- Total Neraca Akhir -->
                        <td class="text-right"><?= number_format($t[8] + $rugi) ?></td>
                        <td class="text-right"><?= number_format($t[9] + $laba) ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>