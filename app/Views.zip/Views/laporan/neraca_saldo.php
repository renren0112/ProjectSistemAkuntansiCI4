<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<style>
    .filter-box { background: #fff; border-radius: 8px; box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15); border-left: 4px solid #36b9cc; }
    .table-neraca thead th { background-color: #2c3e50; color: white; text-transform: uppercase; font-size: 0.85rem; letter-spacing: 0.05em; vertical-align: middle; }
    .table-neraca tbody tr:hover { background-color: #f8f9fc; }
    .font-mono { font-family: 'Consolas', monospace; font-weight: bold; }
    .badge-status { font-size: 1rem; padding: 10px 20px; border-radius: 50px; }
</style>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Neraca Saldo (Trial Balance)</h1>
</div>

<!-- 1. AREA FILTER -->
<div class="filter-box p-4 mb-4">
    <form action="" method="get">
        <div class="row align-items-end">
            <div class="col-md-3 mb-3 mb-md-0">
                <label class="small font-weight-bold text-gray-600">Bulan (Periode)</label>
                <select name="bulan" class="form-control">
                    <?php for($m=1; $m<=12; $m++): ?>
                        <option value="<?= $m ?>" <?= ($filter_bln == $m) ? 'selected' : '' ?>><?= date('F', mktime(0, 0, 0, $m, 10)) ?></option>
                    <?php endfor; ?>
                </select>
            </div>

            <div class="col-md-2 mb-3 mb-md-0">
                <label class="small font-weight-bold text-gray-600">Tahun</label>
                <input type="number" name="tahun" class="form-control" value="<?= $filter_thn ?>">
            </div>

            <div class="col-md-4 d-flex">
                <button type="submit" class="btn btn-info btn-block mr-2 shadow-sm">
                    <i class="fas fa-filter mr-1"></i> Tampilkan
                </button>
                
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle shadow-sm" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-download mr-1"></i> Export
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" target="_blank" href="<?= base_url("laporan/cetak-neraca?bulan=$filter_bln&tahun=$filter_thn") ?>">
                            <i class="fas fa-file-pdf text-danger mr-2"></i> Cetak PDF
                        </a>
                        <a class="dropdown-item" target="_blank" href="<?= base_url("laporan/export-neraca?bulan=$filter_bln&tahun=$filter_thn") ?>">
                            <i class="fas fa-file-excel text-success mr-2"></i> Export Excel
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<!-- Hitung Total Dulu untuk Indikator Status -->
<?php 
    $grandTotalDebit = 0;
    $grandTotalKredit = 0;
    $data_neraca = []; // Tampung hasil hitung bersih agar tidak hitung 2x di loop tabel

    foreach($neraca as $row) {
        $debit_trans = $row['total_debit'] ?? 0;
        $kredit_trans = $row['total_kredit'] ?? 0;
        $saldo_debit = 0;
        $saldo_kredit = 0;

        if($row['posisi_saldo_normal'] == 'D') {
            $saldo_debit = $debit_trans - $kredit_trans;
            if($saldo_debit < 0) { $saldo_kredit = abs($saldo_debit); $saldo_debit = 0; }
        } else {
            $saldo_kredit = $kredit_trans - $debit_trans;
            if($saldo_kredit < 0) { $saldo_debit = abs($saldo_kredit); $saldo_kredit = 0; }
        }

        $grandTotalDebit += $saldo_debit;
        $grandTotalKredit += $saldo_kredit;
        
        // Simpan data bersih
        $data_neraca[] = [
            'kode' => $row['kode_akun'],
            'nama' => $row['nama_akun'],
            'debit' => $saldo_debit,
            'kredit' => $saldo_kredit
        ];
    }
    
    $is_balance = ($grandTotalDebit == $grandTotalKredit);
?>

<!-- 2. STATUS BALANCE HEADER -->
<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="text-gray-800 font-weight-bold">
        Posisi per Akhir <?= date('F', mktime(0, 0, 0, $filter_bln, 10)) ?> <?= $filter_thn ?>
    </h5>
    <?php if($is_balance): ?>
        <span class="badge badge-success badge-status shadow"><i class="fas fa-check-circle mr-2"></i> SEIMBANG (BALANCE)</span>
    <?php else: ?>
        <span class="badge badge-danger badge-status shadow"><i class="fas fa-times-circle mr-2"></i> TIDAK SEIMBANG! (Selisih: <?= number_format(abs($grandTotalDebit - $grandTotalKredit), 0, ',', '.') ?>)</span>
    <?php endif; ?>
</div>

<!-- 3. TABEL NERACA SALDO -->
<div class="card shadow mb-4 border-top-primary">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-neraca table-striped mb-0">
                <thead>
                    <tr>
                        <th width="15%" class="text-center">Kode Akun</th>
                        <th>Nama Akun</th>
                        <th width="20%" class="text-right">Debit</th>
                        <th width="20%" class="text-right">Kredit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($data_neraca)): ?>
                        <tr><td colspan="4" class="text-center py-5 text-gray-500">Belum ada data transaksi.</td></tr>
                    <?php else: ?>
                        <?php foreach($data_neraca as $row): 
                            // Opsi Filter: Jika ingin sembunyikan saldo 0, tambahkan if($row['debit']==0 && $row['kredit']==0) continue;
                        ?>
                        <tr>
                            <td class="text-center font-weight-bold text-gray-700"><?= $row['kode'] ?></td>
                            <td><?= $row['nama'] ?></td>
                            <td class="text-right font-mono <?= $row['debit'] > 0 ? 'text-gray-900' : 'text-gray-400' ?>">
                                <?= $row['debit'] > 0 ? number_format($row['debit'], 0, ',', '.') : '-' ?>
                            </td>
                            <td class="text-right font-mono <?= $row['kredit'] > 0 ? 'text-gray-900' : 'text-gray-400' ?>">
                                <?= $row['kredit'] > 0 ? number_format($row['kredit'], 0, ',', '.') : '-' ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
                <tfoot class="bg-gray-200 text-dark">
                    <tr class="font-weight-bold" style="font-size: 1.1em;">
                        <td colspan="2" class="text-right text-uppercase">Total</td>
                        <td class="text-right text-primary">Rp <?= number_format($grandTotalDebit, 0, ',', '.') ?></td>
                        <td class="text-right text-primary">Rp <?= number_format($grandTotalKredit, 0, ',', '.') ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>