<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<style>
    .filter-box { background: #fff; border-radius: 8px; box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15); border-left: 4px solid #1cc88a; }
    .font-mono { font-family: 'Consolas', monospace; font-weight: bold; }
</style>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Neraca Saldo Setelah Penutupan</h1>
</div>

<?php if(session()->getFlashdata('success')): ?>
    <div class="alert alert-success border-left-success shadow-sm alert-dismissible fade show" role="alert">
        <i class="fas fa-check-circle mr-2"></i><?= session()->getFlashdata('success') ?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    </div>
<?php endif; ?>

<!-- FILTER -->
<div class="filter-box p-4 mb-4">
    <form action="" method="get">
        <div class="row align-items-end">
            <div class="col-md-3 mb-3 mb-md-0">
                <label class="small font-weight-bold text-gray-600">Bulan (Periode)</label>
                <select name="bulan" class="form-control">
                    <?php for($m=1; $m<=12; $m++): ?>
                        <option value="<?= $m ?>" <?= ($filter_bln == $m) ? 'selected' : '' ?>><?= date('F', mktime(0, 0, 0, $m, 10)) ?></option>
                    <?php endfor; ?>
                </select>
            </div>

            <div class="col-md-2 mb-3 mb-md-0">
                <label class="small font-weight-bold text-gray-600">Tahun</label>
                <input type="number" name="tahun" class="form-control" value="<?= $filter_thn ?>">
            </div>

            <div class="col-md-4 d-flex">
                <button type="submit" class="btn btn-success btn-block mr-2 shadow-sm">
                    <i class="fas fa-filter mr-1"></i> Tampilkan
                </button>
                
                <!-- TOMBOL DOWNLOAD -->
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle shadow-sm" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-download mr-1"></i> Export
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" target="_blank" href="<?= base_url("laporan/cetak-neraca-penutup?bulan=$filter_bln&tahun=$filter_thn") ?>">
                            <i class="fas fa-file-pdf text-danger mr-2"></i> Cetak PDF
                        </a>
                        <a class="dropdown-item" target="_blank" href="<?= base_url("laporan/export-neraca-penutup?bulan=$filter_bln&tahun=$filter_thn") ?>">
                            <i class="fas fa-file-excel text-success mr-2"></i> Export Excel
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<!-- TABEL (Sama seperti sebelumnya) -->
<div class="card shadow mb-4 border-top-success">
    <div class="card-header py-3 bg-white d-flex justify-content-between align-items-center">
        <div>
            <h6 class="m-0 font-weight-bold text-success">Posisi Akun Akhir Periode</h6>
            <small class="text-muted">Akun Nominal (Pendapatan & Beban) harus bernilai 0.</small>
        </div>
        <span class="badge badge-success px-3 py-2">Post-Closing Trial Balance</span>
    </div>
    
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped mb-0">
                <thead class="bg-success text-white">
                    <tr>
                        <th width="15%" class="text-center">Kode Akun</th>
                        <th>Nama Akun</th>
                        <th width="20%" class="text-right">Debit</th>
                        <th width="20%" class="text-right">Kredit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $grandTotalDebit = 0; $grandTotalKredit = 0;
                    foreach($neraca as $row): 
                        // Hitung Saldo
                        $saldo_debit = 0; $saldo_kredit = 0;
                        if($row['posisi_saldo_normal'] == 'D') {
                            $saldo_debit = $row['total_debit'] - $row['total_kredit'];
                            if($saldo_debit < 0) { $saldo_kredit = abs($saldo_debit); $saldo_debit = 0; }
                        } else {
                            $saldo_kredit = $row['total_kredit'] - $row['total_debit'];
                            if($saldo_kredit < 0) { $saldo_debit = abs($saldo_kredit); $saldo_kredit = 0; }
                        }

                        // Filter: Sembunyikan akun yang saldonya 0 
                        if ($saldo_debit == 0 && $saldo_kredit == 0) continue;

                        $grandTotalDebit += $saldo_debit;
                        $grandTotalKredit += $saldo_kredit;
                    ?>
                    <tr>
                        <td class="text-center font-weight-bold text-gray-700"><?= $row['kode_akun'] ?></td>
                        <td><?= $row['nama_akun'] ?></td>
                        <td class="text-right font-mono text-gray-900">
                            <?= $saldo_debit > 0 ? number_format($saldo_debit, 0, ',', '.') : '-' ?>
                        </td>
                        <td class="text-right font-mono text-gray-900">
                            <?= $saldo_kredit > 0 ? number_format($saldo_kredit, 0, ',', '.') : '-' ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot class="bg-gray-100 font-weight-bold">
                    <tr>
                        <td colspan="2" class="text-right">TOTAL</td>
                        <td class="text-right text-success">Rp <?= number_format($grandTotalDebit, 0, ',', '.') ?></td>
                        <td class="text-right text-success">Rp <?= number_format($grandTotalKredit, 0, ',', '.') ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>