<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Laporan Perubahan Modal</h1>
</div>

<!-- Filter -->
<div class="card shadow mb-4 border-left-warning">
    <div class="card-body py-3">
        <form action="" method="get" class="form-inline">
            <label class="mr-2 font-weight-bold">Periode:</label>
            <select name="bulan" class="form-control mr-2">
                <?php for($m=1; $m<=12; $m++): ?>
                    <option value="<?= $m ?>" <?= ($filter_bln == $m) ? 'selected' : '' ?>><?= date('F', mktime(0, 0, 0, $m, 10)) ?></option>
                <?php endfor; ?>
            </select>
            <input type="number" name="tahun" class="form-control mr-3" value="<?= $filter_thn ?>" style="width: 100px;">
            <button type="submit" class="btn btn-warning text-white shadow-sm mr-2"><i class="fas fa-search mr-1"></i> Tampilkan</button>
            
            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle shadow-sm" type="button" id="dropdownMenuButton" data-toggle="dropdown">
                    <i class="fas fa-download mr-1"></i> Export
                </button>
                <div class="dropdown-menu">
                    <a class="dropdown-item" target="_blank" href="<?= base_url("laporan/cetak-perubahan-modal?bulan=$filter_bln&tahun=$filter_thn") ?>">
                        <i class="fas fa-file-pdf text-danger mr-2"></i> Cetak PDF
                    </a>
                    <a class="dropdown-item" target="_blank" href="<?= base_url("laporan/export-perubahan-modal?bulan=$filter_bln&tahun=$filter_thn") ?>">
                        <i class="fas fa-file-excel text-success mr-2"></i> Export Excel
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Kertas Laporan -->
<div class="card shadow-lg mb-4">
    <div class="card-body p-5">
        
        <!-- Kop Laporan -->
        <div class="text-center mb-5">
            <h4 class="font-weight-bold text-uppercase text-gray-900 mb-1">PRIMA COMPUTINDO</h4>
            <h5 class="font-weight-bold text-gray-800">LAPORAN PERUBAHAN MODAL</h5>
            <p class="text-gray-600">Periode Berakhir <?= date('d F Y', mktime(0, 0, 0, $filter_bln + 1, 0, $filter_thn)) ?></p>
            <hr class="border-dark mt-4">
        </div>

        <div class="table-responsive">
            <table class="table table-hover">
                <tbody>
                    <?php 
                    $modal_awal = 0;
                    $prive = 0;
                    $penambahan_modal = 0; // Jika ada setoran modal tambahan selain laba

                    // Pisahkan komponen Ekuitas
                    foreach($ekuitas as $e) {
                        // Saldo Normal Kredit = Modal / Setoran
                        if ($e['posisi_saldo_normal'] == 'K') {
                            // Asumsi sederhana: Akun dengan nama 'Modal' adalah modal awal
                            // (Idealnya dipisah berdasarkan tanggal transaksi, tapi untuk periodik sederhana kita pakai saldo berjalan)
                            $modal_awal += ($e['total_kredit'] - $e['total_debit']); 
                        } else {
                            // Saldo Normal Debit = Prive / Pengambilan
                            $prive += ($e['total_debit'] - $e['total_kredit']); 
                        }
                    }
                    ?>
                    
                    <!-- Modal Awal -->
                    <tr>
                        <td class="font-weight-bold text-gray-900 pl-4 py-3" style="font-size: 1.1em;">Modal Awal</td>
                        <td class="text-right font-weight-bold text-gray-900 py-3" style="font-family: Consolas; font-size: 1.1em;">Rp <?= number_format($modal_awal, 0, ',', '.') ?></td>
                    </tr>
                    
                    <!-- Laba Bersih -->
                    <tr>
                        <td class="pl-4 text-gray-700">Ditambah: Laba Bersih Tahun Berjalan</td>
                        <td class="text-right text-success font-weight-bold" style="font-family: Consolas;">Rp <?= number_format($laba_bersih, 0, ',', '.') ?></td>
                    </tr>
                    
                    <!-- Prive -->
                    <?php if($prive > 0): ?>
                    <tr>
                        <td class="pl-4 text-gray-700">Dikurangi: Prive / Penarikan Pribadi</td>
                        <td class="text-right text-danger font-weight-bold" style="font-family: Consolas;">(Rp <?= number_format($prive, 0, ',', '.') ?>)</td>
                    </tr>
                    <?php endif; ?>

                    <!-- Kenaikan / Penurunan -->
                    <tr class="bg-gray-100">
                        <td class="pl-4 font-italic text-gray-600">Kenaikan (Penurunan) Modal Bersih</td>
                        <td class="text-right font-weight-bold text-primary" style="font-family: Consolas; border-top: 1px solid #ccc;">
                            <?php $kenaikan = $laba_bersih - $prive; ?>
                            Rp <?= number_format($kenaikan, 0, ',', '.') ?>
                        </td>
                    </tr>
                </tbody>
                
                <!-- Modal Akhir -->
                <tfoot class="bg-warning text-white">
                    <tr style="font-size: 1.2em;">
                        <th class="text-uppercase pl-4 py-3">Modal Akhir, <?= date('d F Y', mktime(0, 0, 0, $filter_bln + 1, 0, $filter_thn)) ?></th>
                        <th class="text-right py-3" style="font-family: Consolas;">Rp <?= number_format($modal_awal + $kenaikan, 0, ',', '.') ?></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>