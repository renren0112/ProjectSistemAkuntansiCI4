<ul class="navbar-nav bg-gradient-dark sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= base_url() ?>">
        <div class="sidebar-brand-icon">
            <i class="fas fa-calculator"></i>
        </div>
        <div class="sidebar-brand-text mx-3">SI Akuntansi</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('/') ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <div class="sidebar-heading">
        Menu Utama
    </div>

    <!-- 1. GROUP MASTER DATA -->
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseMaster"
            aria-expanded="true" aria-controls="collapseMaster">
            <i class="fas fa-fw fa-database"></i>
            <span>Master Data</span>
        </a>
        <div id="collapseMaster" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Data Referensi:</h6>
                <a class="collapse-item" href="<?= base_url('akun') ?>">Data Akun (COA)</a>
                <!-- BARU: Periode Akuntansi -->
                <a class="collapse-item" href="<?= base_url('periode') ?>">Periode Akuntansi</a>
                <!-- Link Kelola Pengguna -->
                <a class="collapse-item" href="<?= base_url('user') ?>">Kelola Pengguna</a>
            </div>
        </div>
    </li>

    <!-- 2. GROUP TRANSAKSI -->
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTrx" ...>
            <i class="fas fa-fw fa-exchange-alt"></i>
            <span>Transaksi Jurnal</span>
        </a>
        <div id="collapseTrx" class="collapse" ...>
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Input Data:</h6>
                <a class="collapse-item" href="<?= base_url('transaksi/create') ?>">Jurnal Umum</a>
                
                <!-- BARU -->
                <a class="collapse-item" href="<?= base_url('transaksi/penjualan') ?>">Jurnal Penjualan</a>
                <a class="collapse-item" href="<?= base_url('transaksi/pembelian') ?>">Jurnal Pembelian</a>
                
                <a class="collapse-item" href="<?= base_url('transaksi/penyesuaian') ?>">Jurnal Penyesuaian</a>
                <div class="collapse-divider"></div>
                <a class="collapse-item" href="<?= base_url('transaksi') ?>">Riwayat Jurnal</a>
            </div>
        </div>
    </li>

    <!-- 3. GROUP LAPORAN -->
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLaporan"
            aria-expanded="true" aria-controls="collapseLaporan">
            <i class="fas fa-fw fa-file-invoice-dollar"></i>
            <span>Laporan Keuangan</span>
        </a>
        <div id="collapseLaporan" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Buku & Neraca:</h6>
                <a class="collapse-item" href="<?= base_url('laporan/buku-besar') ?>">Buku Besar</a>
                <a class="collapse-item" href="<?= base_url('laporan/neraca-saldo') ?>">Neraca Saldo</a>
                <div class="collapse-divider"></div>
                <h6 class="collapse-header">Financial Report:</h6>
                <a class="collapse-item" href="<?= base_url('laporan/laba-rugi') ?>">Laba Rugi</a>
                <a class="collapse-item" href="<?= base_url('laporan/perubahan-modal') ?>">Perubahan Modal</a>
                <a class="collapse-item" href="<?= base_url('laporan/neraca') ?>">Posisi Keuangan (Neraca)</a>
                <a class="collapse-item" href="<?= base_url('laporan/arus-kas') ?>">Arus Kas</a>
                <div class="collapse-divider"></div>
                <h6 class="collapse-header">Analisis:</h6>
                <a class="collapse-item" href="<?= base_url('laporan/neraca-lajur') ?>">Neraca Lajur (Worksheet)</a>
                <div class="collapse-divider"></div>
                <h6 class="collapse-header">Akhir Periode:</h6>
                <a class="collapse-item" href="<?= base_url('penutupan') ?>">Proses Tutup Buku</a>
                <a class="collapse-item" href="<?= base_url('laporan/neraca-saldo-penutup') ?>">NS Setelah Penutupan</a>
            </div>
        </div>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Nav Item - Logout -->
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('logout') ?>">
            <i class="fas fa-fw fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>
    </li>

    <!-- Sidebar Toggler -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul>