<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container-fluid">
    <h4 class="mb-3">Periode Akuntansi</h4>

    <?php if (session()->getFlashdata('success')) : ?>
        <div class="alert alert-success">
            <?= session()->getFlashdata('success') ?>
        </div>
    <?php endif; ?>
        <a href="<?= base_url('periode/create') ?>" class="btn btn-success mb-3">
    <i class="fas fa-plus"></i> Tambah Periode
</a>

    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>Periode</th>
                <th>Tanggal</th>
                <th>Status</th>
                <th width="120">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; foreach ($periode as $p) : ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= $p['nama_periode'] ?></td>
                <td>
                    <?= date('d-m-Y', strtotime($p['tgl_mulai'])) ?> s/d
                    <?= date('d-m-Y', strtotime($p['tgl_selesai'])) ?>
                </td>
                <td>
                    <?php if ($p['status'] == 'OPEN') : ?>
                        <span class="badge bg-success">OPEN</span>
                    <?php else : ?>
                        <span class="badge bg-secondary">CLOSED</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($p['status'] == 'CLOSED') : ?>
                        <a href="<?= base_url('periode/open/'.$p['id']) ?>"
                           class="btn btn-sm btn-primary"
                           onclick="return confirm('Buka periode ini?')">
                            Open
                        </a>
                    <?php else : ?>
                        <button class="btn btn-sm btn-secondary" disabled>Aktif</button>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<?= $this->endSection() ?>
