<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Voucher <?= $jurnal[0]['no_bukti'] ?></title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; font-size: 13px; color: #333; margin: 0; padding: 20px; background: #eef1f5; }
        
        /* Kertas A4 */
        .page-container {
            max-width: 800px; margin: 0 auto; background: white; padding: 40px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1); border-top: 5px solid #4e73df;
        }

        /* Navigasi Preview */
        .preview-nav {
            max-width: 800px; margin: 0 auto 20px auto; text-align: right; background: #333; padding: 10px; border-radius: 5px; color: white; display: flex; justify-content: space-between; align-items: center;
        }
        .btn { padding: 6px 15px; border: none; border-radius: 4px; cursor: pointer; font-weight: bold; text-decoration: none; font-size: 12px; }
        .btn-print { background: #fff; color: #333; }
        .btn-close { background: #e74a3b; color: white; margin-left: 10px; }

        /* Judul Dinamis */
        <?php 
            $jenis = $jurnal[0]['jenis_transaksi'] ?? 'Umum';
            $judul = "BUKTI JURNAL UMUM";
            $warna = "#4e73df";
            if($jenis == 'Penjualan') { $judul = "FAKTUR PENJUALAN"; $warna = "#1cc88a"; }
            elseif($jenis == 'Pembelian') { $judul = "BUKTI PEMBELIAN"; $warna = "#e74a3b"; }
            elseif($jenis == 'Penyesuaian') { $judul = "MEMO PENYESUAIAN"; $warna = "#36b9cc"; }
            elseif($jenis == 'Penutup') { $judul = "JURNAL PENUTUP"; $warna = "#858796"; }
        ?>
        
        .header { border-bottom: 2px solid <?= $warna ?>; margin-bottom: 30px; padding-bottom: 15px; display: flex; justify-content: space-between; align-items: flex-end; }
        .company-name { font-size: 20px; font-weight: bold; color: #333; text-transform: uppercase; margin: 0; }
        .doc-title { font-size: 24px; font-weight: bold; color: <?= $warna ?>; text-transform: uppercase; margin: 0; }
        
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th { background-color: #f8f9fc; padding: 10px; border: 1px solid #ddd; text-align: left; }
        td { padding: 8px 10px; border: 1px solid #ddd; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .font-bold { font-weight: bold; }
        
        .meta-info td { border: none; padding: 3px 0; }
        
        .signature { margin-top: 60px; display: flex; justify-content: space-between; text-align: center; }
        .sig-box { width: 30%; }
        .sig-line { border-top: 1px solid #333; margin-top: 60px; padding-top: 5px; font-weight: bold; }

        @media print {
            body { background: white; padding: 0; }
            .page-container { box-shadow: none; border: none; margin: 0; width: 100%; max-width: 100%; padding: 0; }
            .preview-nav { display: none !important; }
        }
    </style>
</head>
<body>

    <?php if(!isset($is_excel) || !$is_excel): ?>
    <div class="preview-nav">
        <span>Mode Preview Cetak</span>
        <div>
            <button onclick="window.print()" class="btn btn-print">🖨️ Cetak / PDF</button>
            <button onclick="window.close()" class="btn btn-close">❌ Tutup</button>
        </div>
    </div>
    <?php endif; ?>

    <div class="page-container">
        
        <div class="header">
            <div>
                <h1 class="company-name">Prima Computindo</h1>
                <p style="margin:5px 0; font-size:11px; color:#666;">Jl. Teknologi No. 10, Jakarta Pusat<br>Telp: 021-99887766</p>
            </div>
            <div style="text-align: right;">
                <h2 class="doc-title"><?= $judul ?></h2>
                <p style="margin:5px 0; font-size:14px;">NO: <strong><?= $jurnal[0]['no_bukti'] ?></strong></p>
            </div>
        </div>

        <!-- Info Transaksi -->
        <table class="meta-info" style="width: 100%; margin-bottom: 20px; border: none;">
            <tr>
                <td width="15%" class="font-bold">Tanggal</td>
                <td width="2%">:</td>
                <td><?= date('d F Y', strtotime($jurnal[0]['tgl_jurnal'])) ?></td>
            </tr>
            <tr>
                <td class="font-bold">Keterangan</td>
                <td>:</td>
                <td><?= $jurnal[0]['keterangan'] ?></td>
            </tr>
            <tr>
                <td class="font-bold">Jenis</td>
                <td>:</td>
                <td><?= $jenis ?></td>
            </tr>
        </table>

        <!-- Tabel Rincian -->
        <table>
            <thead>
                <tr>
                    <th width="15%">Kode Akun</th>
                    <th>Nama Akun / Deskripsi</th>
                    <th width="20%" class="text-right">Debit</th>
                    <th width="20%" class="text-right">Kredit</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $totalDebit = 0;
                $totalKredit = 0;
                foreach($jurnal as $row): 
                    $totalDebit += $row['debit'];
                    $totalKredit += $row['kredit'];
                ?>
                <tr>
                    <td class="text-center"><?= $row['kode_akun'] ?></td>
                    <td><?= $row['nama_akun'] ?></td>
                    <td class="text-right"><?= $row['debit'] > 0 ? number_format($row['debit'], 0, ',', '.') : '-' ?></td>
                    <td class="text-right"><?= $row['kredit'] > 0 ? number_format($row['kredit'], 0, ',', '.') : '-' ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr style="background-color: #f8f9fc;">
                    <td colspan="2" class="text-right font-bold">TOTAL</td>
                    <td class="text-right font-bold">Rp <?= number_format($totalDebit, 0, ',', '.') ?></td>
                    <td class="text-right font-bold">Rp <?= number_format($totalKredit, 0, ',', '.') ?></td>
                </tr>
            </tfoot>
        </table>

        <div style="margin-top: 15px; font-style: italic; font-size: 11px; color: #666;">
            Terbilang: # <em><?= number_format($totalDebit, 0, ',', '.') ?> Rupiah</em> #
        </div>

        <div class="signature">
            <div class="sig-box">
                <p>Dibuat Oleh,</p>
                <div class="sig-line">( Admin )</div>
            </div>
            <div class="sig-box">
                <p>Diperiksa Oleh,</p>
                <div class="sig-line">( Accounting )</div>
            </div>
            <div class="sig-box">
                <p>Disetujui Oleh,</p>
                <div class="sig-line">( Manajer Keuangan )</div>
            </div>
        </div>

    </div>

</body>
</html>