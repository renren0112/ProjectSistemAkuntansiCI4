<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Input Jurnal Pembelian</h1>
    <a href="<?= base_url('transaksi') ?>" class="btn btn-secondary btn-sm shadow-sm">
        <i class="fas fa-arrow-left fa-sm text-white-50"></i> Kembali
    </a>
</div>

<div class="card shadow mb-4 border-left-danger">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-danger"><i class="fas fa-shopping-cart mr-2"></i>Transaksi Pembelian Stok</h6>
    </div>
    <div class="card-body">
        
        <?php if(session()->getFlashdata('error')): ?>
            <div class="alert alert-danger shadow-sm">
                <?= session()->getFlashdata('error') ?>
            </div>
        <?php endif; ?>

        <form action="<?= base_url('transaksi/store') ?>" method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="jenis_transaksi" value="Pembelian">
            
            <!-- HEADER -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <label class="font-weight-bold">No. Bukti (Otomatis)</label>
                    <input type="text" name="no_bukti" class="form-control font-weight-bold text-danger" value="<?= $no_bukti_auto ?>" readonly>
                </div>
                <div class="col-md-3">
                    <label class="font-weight-bold">Tanggal</label>
                    <input type="date" name="tgl_jurnal" class="form-control" value="<?= date('Y-m-d') ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="font-weight-bold">Keterangan</label>
                    <input type="text" name="keterangan" class="form-control" placeholder="Contoh: Pembelian Stok Laptop dari Vendor A" required>
                </div>
            </div>

            <!-- DETAIL AKUN -->
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class="thead-light">
                        <tr>
                            <th width="40%">Akun</th>
                            <th width="30%">Debit</th>
                            <th width="30%">Kredit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- BARIS 1: DEBIT (PEMBELIAN) -->
                        <tr>
                            <td>
                                <label class="small font-weight-bold text-danger">Barang Masuk / Pembelian (Debit):</label>
                                <select name="kode_akun[]" class="form-control" required>
                                    <option value="">-- Pilih Akun Pembelian --</option>
                                    <?php foreach($akun as $row): ?>
                                        <!-- UPDATE: HANYA TAMPILKAN TIPE 'PEMBELIAN' -->
                                        <?php if($row['tipe_akun'] == 'Pembelian'): ?>
                                            <option value="<?= $row['kode_akun'] ?>"><?= $row['kode_akun'] ?> - <?= $row['nama_akun'] ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <div class="input-group">
                                    <div class="input-group-prepend"><span class="input-group-text">Rp</span></div>
                                    <input type="number" name="debit[]" id="nominal_transaksi" class="form-control font-weight-bold text-danger" placeholder="0" required onkeyup="syncNominal()">
                                </div>
                            </td>
                            <td>
                                <input type="hidden" name="kredit[]" value="0">
                                <input type="text" class="form-control bg-light" value="0" readonly>
                            </td>
                        </tr>

                        <!-- BARIS 2: KREDIT (KAS / UTANG) -->
                        <tr>
                            <td>
                                <label class="small font-weight-bold text-primary">Bayar Menggunakan (Kredit):</label>
                                <select name="kode_akun[]" class="form-control" required>
                                    <option value="">-- Pilih Akun Kas / Utang --</option>
                                    <?php foreach($akun as $row): ?>
                                        <!-- Kredit Pembelian biasanya Kas atau Utang -->
                                        <?php if(in_array($row['tipe_akun'], ['Aset', 'Liabilitas'])): ?>
                                            <option value="<?= $row['kode_akun'] ?>"><?= $row['kode_akun'] ?> - <?= $row['nama_akun'] ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <input type="hidden" name="debit[]" value="0">
                                <input type="text" class="form-control bg-light" value="0" readonly>
                            </td>
                            <td>
                                <div class="input-group">
                                    <div class="input-group-prepend"><span class="input-group-text">Rp</span></div>
                                    <input type="number" name="kredit[]" id="nominal_kredit_auto" class="form-control font-weight-bold" value="0" readonly>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="text-right mt-3">
                <button type="submit" class="btn btn-danger px-5 shadow"><i class="fas fa-save mr-2"></i> Simpan Pembelian</button>
            </div>
        </form>
    </div>
</div>

<script>
    function syncNominal() {
        var val = document.getElementById('nominal_transaksi').value;
        document.getElementById('nominal_kredit_auto').value = val;
    }
</script>
<?= $this->endSection(); ?>