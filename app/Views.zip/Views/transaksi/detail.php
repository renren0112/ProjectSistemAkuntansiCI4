<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<?php
    // Tentukan Warna & Ikon berdasarkan Jenis
    $jenis = $jurnal[0]['jenis_transaksi'] ?? 'Umum';
    $themeColor = 'primary'; // Default Biru
    $icon = 'fa-file-alt';

    if ($jenis == 'Penjualan') { $themeColor = 'success'; $icon = 'fa-cash-register'; }
    elseif ($jenis == 'Pembelian') { $themeColor = 'danger'; $icon = 'fa-shopping-cart'; }
    elseif ($jenis == 'Penyesuaian') { $themeColor = 'info'; $icon = 'fa-sliders-h'; }
    elseif ($jenis == 'Penutup') { $themeColor = 'secondary'; $icon = 'fa-archive'; }
    elseif ($jenis == 'Koreksi') { $themeColor = 'warning'; $icon = 'fa-eraser'; }
?>

<div class="row justify-content-center">
    <div class="col-lg-10">
        
        <!-- Tombol Navigasi -->
        <div class="d-flex justify-content-between mb-3">
            <a href="<?= base_url('transaksi') ?>" class="btn btn-light border shadow-sm">
                <i class="fas fa-arrow-left mr-1"></i> Kembali
            </a>
            <div>
                <!-- Tombol Export Excel -->
                <a href="<?= base_url('transaksi/export/'.$jurnal[0]['id_jurnal']) ?>" target="_blank" class="btn btn-success shadow-sm mr-2">
                    <i class="fas fa-file-excel mr-1"></i> Export Excel
                </a>
                <!-- Tombol Cetak PDF -->
                <a href="<?= base_url('transaksi/cetak/'.$jurnal[0]['id_jurnal']) ?>" target="_blank" class="btn btn-secondary shadow-sm">
                    <i class="fas fa-print mr-1"></i> Cetak Voucher
                </a>
            </div>
        </div>

        <div class="card shadow mb-4 border-left-<?= $themeColor ?>">
            <!-- Header Kartu -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between bg-white">
                <h6 class="m-0 font-weight-bold text-<?= $themeColor ?>">
                    <i class="fas <?= $icon ?> mr-2"></i> Detail Transaksi: <?= strtoupper($jenis) ?>
                </h6>
                <span class="badge badge-<?= $themeColor ?> px-3 py-2" style="font-size: 0.9em;">
                    <?= $jurnal[0]['no_bukti'] ?>
                </span>
            </div>

            <div class="card-body">
                
                <!-- Informasi Utama -->
                <div class="row mb-4 p-3 bg-gray-100 rounded mx-0">
                    <div class="col-md-4">
                        <small class="text-uppercase text-gray-500 font-weight-bold">Tanggal Transaksi</small>
                        <h5 class="text-gray-900 font-weight-bold mt-1">
                            <?= date('d F Y', strtotime($jurnal[0]['tgl_jurnal'])) ?>
                        </h5>
                    </div>
                    <div class="col-md-8">
                        <small class="text-uppercase text-gray-500 font-weight-bold">Keterangan / Deskripsi</small>
                        <p class="text-gray-800 mt-1 mb-0 font-italic">"<?= $jurnal[0]['keterangan'] ?> "</p>
                    </div>
                </div>

                <!-- Tabel Rincian -->
                <div class="table-responsive">
                    <table class="table table-bordered table-hover" width="100%" cellspacing="0">
                        <thead class="bg-gray-200 text-gray-900">
                            <tr>
                                <th width="15%">Kode Akun</th>
                                <th>Nama Akun</th>
                                <th width="20%" class="text-right">Debit</th>
                                <th width="20%" class="text-right">Kredit</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $totalDebit = 0;
                            $totalKredit = 0;
                            foreach($jurnal as $row): 
                                $totalDebit += $row['debit'];
                                $totalKredit += $row['kredit'];
                            ?>
                            <tr>
                                <td class="text-center font-weight-bold"><?= $row['kode_akun'] ?></td>
                                <td><?= $row['nama_akun'] ?></td>
                                <td class="text-right text-gray-800">
                                    <?= $row['debit'] > 0 ? 'Rp '.number_format($row['debit'], 0, ',', '.') : '-' ?>
                                </td>
                                <td class="text-right text-gray-800">
                                    <?= $row['kredit'] > 0 ? 'Rp '.number_format($row['kredit'], 0, ',', '.') : '-' ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot class="font-weight-bold text-uppercase">
                            <tr class="bg-<?= $themeColor ?> text-white">
                                <td colspan="2" class="text-right border-0">Total Nilai Transaksi</td>
                                <td class="text-right border-0">Rp <?= number_format($totalDebit, 0, ',', '.') ?></td>
                                <td class="text-right border-0">Rp <?= number_format($totalKredit, 0, ',', '.') ?></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>

                <!-- Footer Status -->
                <div class="mt-4 d-flex justify-content-between align-items-center">
                    <div class="small text-muted">
                        <i class="fas fa-clock mr-1"></i> Waktu Input: <?= date('d/m/Y H:i', strtotime($jurnal[0]['created_at'])) ?>
                        <br>
                        <i class="fas fa-user mr-1"></i> Diinput Oleh: Admin
                    </div>
                    <div>
                        <?php if($totalDebit == $totalKredit): ?>
                            <span class="text-success font-weight-bold"><i class="fas fa-check-circle mr-1"></i> Status: BALANCE</span>
                        <?php else: ?>
                            <span class="text-danger font-weight-bold"><i class="fas fa-times-circle mr-1"></i> Status: TIDAK SEIMBANG</span>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>

    </div>
</div>
<?= $this->endSection(); ?>