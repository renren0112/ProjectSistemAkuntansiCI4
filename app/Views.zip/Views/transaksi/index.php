<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<style>
    .pagination { justify-content: center; margin-top: 20px; }
    .page-item.active .page-link { background-color: #4e73df; border-color: #4e73df; }
    .table-hover tbody tr:hover { background-color: rgba(78, 115, 223, 0.05); }
    .filter-box { background: #f8f9fc; border-radius: 0 0 8px 8px; border: 1px solid #e3e6f0; border-top: none; }
    
    .journal-row td { vertical-align: top; }
    .kredit-indent { padding-left: 30px !important; color: #e74a3b; }
    
    /* Styling Badge Jenis */
    .badge-jenis-umum { background-color: #4e73df; color: white; }
    .badge-jenis-penjualan { background-color: #1cc88a; color: white; }
    .badge-jenis-pembelian { background-color: #e74a3b; color: white; }
    .badge-jenis-koreksi { background-color: #f6c23e; color: white; }
    .badge-jenis-penyesuaian { background-color: #36b9cc; color: white; }
    .badge-jenis-penutup { background-color: #858796; color: white; }

    /* Styling Badge Status */
    .badge-status-posted { background-color: #1cc88a; color: white; }
    .badge-status-pending { background-color: #f6c23e; color: white; }
    
    /* Custom Tab Style */
    .nav-tabs .nav-link { color: #858796; font-weight: 600; }
    .nav-tabs .nav-link.active { color: #4e73df; border-bottom: 3px solid #4e73df; background-color: #fff; }
</style>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Riwayat Jurnal Umum</h1>
    <div class="dropdown no-arrow">
        <button class="btn btn-primary btn-sm dropdown-toggle shadow-sm rounded-pill px-3" type="button" id="dropdownMenuButton" data-toggle="dropdown">
            <i class="fas fa-plus fa-sm text-white-50 mr-2"></i> Input Transaksi Baru
        </button>
        <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in">
            <div class="dropdown-header">Pilih Jenis Transaksi:</div>
            <a class="dropdown-item" href="<?= base_url('transaksi/penjualan') ?>"><i class="fas fa-cash-register mr-2 text-success"></i> Penjualan</a>
            <a class="dropdown-item" href="<?= base_url('transaksi/pembelian') ?>"><i class="fas fa-shopping-cart mr-2 text-danger"></i> Pembelian</a>
            <a class="dropdown-item" href="<?= base_url('transaksi/create') ?>"><i class="fas fa-file-alt mr-2 text-primary"></i> Jurnal Umum</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="<?= base_url('transaksi/penyesuaian') ?>"><i class="fas fa-sliders-h mr-2 text-info"></i> Penyesuaian (AJP)</a>
        </div>
    </div>
</div>

<div class="card shadow mb-4">
    <!-- TAB KATEGORI TRANSAKSI -->
    <div class="card-header border-bottom-0 pb-0 bg-white">
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <!-- Helper function untuk generate link tab dengan mempertahankan filter lain -->
            <?php 
                function tab_url($jenis, $current_filter) {
                    $params = $current_filter;
                    $params['jenis'] = $jenis;
                    // Reset page ke 1 saat ganti tab
                    $params['page_jurnal'] = 1; 
                    return base_url('transaksi') . '?' . http_build_query($params);
                }
            ?>
            
            <li class="nav-item">
                <a class="nav-link <?= empty($filter['jenis']) ? 'active' : '' ?>" href="<?= tab_url('', $filter) ?>">Semua</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $filter['jenis'] == 'Penjualan' ? 'active' : '' ?>" href="<?= tab_url('Penjualan', $filter) ?>">Penjualan</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $filter['jenis'] == 'Pembelian' ? 'active' : '' ?>" href="<?= tab_url('Pembelian', $filter) ?>">Pembelian</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $filter['jenis'] == 'Umum' ? 'active' : '' ?>" href="<?= tab_url('Umum', $filter) ?>">Umum</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $filter['jenis'] == 'Penyesuaian' ? 'active' : '' ?>" href="<?= tab_url('Penyesuaian', $filter) ?>">Penyesuaian</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $filter['jenis'] == 'Penutup' ? 'active' : '' ?>" href="<?= tab_url('Penutup', $filter) ?>">Penutup</a>
            </li>
        </ul>
    </div>

    <!-- FORM FILTER & MODE -->
    <div class="px-3 pt-3 bg-white border-left border-right">
        <form action="" method="get">
            <!-- Hidden inputs untuk menjaga state tab saat filter di-submit -->
            <input type="hidden" name="jenis" value="<?= $filter['jenis'] ?>">
            
            <div class="d-flex justify-content-between align-items-center mb-2">
                <!-- MODE SWITCHER (Pills) -->
                <ul class="nav nav-pills">
                    <li class="nav-item">
                        <label class="mr-2 mt-2 small text-gray-600 font-weight-bold">Tampilan:</label>
                    </li>
                    <li class="nav-item">
                        <button type="submit" name="mode" value="ringkas" class="btn btn-sm <?= ($filter['mode'] == 'ringkas') ? 'btn-primary' : 'btn-light border' ?> mr-1">
                            <i class="fas fa-list"></i> Ringkas
                        </button>
                    </li>
                    <li class="nav-item">
                        <button type="submit" name="mode" value="detail" class="btn btn-sm <?= ($filter['mode'] == 'detail') ? 'btn-primary' : 'btn-light border' ?>">
                            <i class="fas fa-book-open"></i> Detail
                        </button>
                    </li>
                </ul>
            </div>

            <div class="filter-box p-3 mb-3">
                <div class="row align-items-end">
                    <div class="col-md-3 mb-2">
                        <label class="small font-weight-bold text-gray-600">Cari Data</label>
                        <div class="input-group input-group-sm">
                            <div class="input-group-prepend"><span class="input-group-text bg-white"><i class="fas fa-search text-gray-400"></i></span></div>
                            <input type="text" name="keyword" class="form-control" placeholder="No Bukti / Keterangan..." value="<?= $filter['keyword'] ?>">
                        </div>
                    </div>
                    <div class="col-md-2 mb-2">
                        <label class="small font-weight-bold text-gray-600">Status</label>
                        <select name="status" class="form-control form-control-sm">
                            <option value="">- Semua -</option>
                            <option value="Pending" <?= $filter['status'] == 'Pending' ? 'selected' : '' ?>>Pending</option>
                            <option value="Posted" <?= $filter['status'] == 'Posted' ? 'selected' : '' ?>>Posted</option>
                        </select>
                    </div>
                    <div class="col-md-2 mb-2">
                        <label class="small font-weight-bold text-gray-600">Dari Tanggal</label>
                        <input type="date" name="start_date" class="form-control form-control-sm" value="<?= $filter['start'] ?>">
                    </div>
                    <div class="col-md-2 mb-2">
                        <label class="small font-weight-bold text-gray-600">Sampai Tanggal</label>
                        <input type="date" name="end_date" class="form-control form-control-sm" value="<?= $filter['end'] ?>">
                    </div>
                    <div class="col-md-3 mb-2">
                        <button type="submit" class="btn btn-primary btn-sm btn-block" title="Terapkan Filter"><i class="fas fa-filter mr-1"></i> Filter</button>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <div class="card-body pt-0">
        
        <?php if(session()->getFlashdata('success')): ?>
            <div class="alert alert-success border-left-success alert-dismissible fade show mt-3" role="alert">
                <?= session()->getFlashdata('success') ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
        <?php endif; ?>

        <?php if(session()->getFlashdata('error')): ?>
            <div class="alert alert-danger border-left-danger alert-dismissible fade show mt-3" role="alert">
                <?= session()->getFlashdata('error') ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
        <?php endif; ?>

        <!-- AREA NOTIFIKASI POSTING OTOMATIS -->
        <?php if (isset($jumlah_pending) && $jumlah_pending > 0): ?>
            <div class="alert <?= ($jumlah_pending > 10) ? 'alert-warning' : 'alert-info' ?> shadow-sm d-flex justify-content-between align-items-center mt-2">
                <div>
                    <i class="fas fa-info-circle mr-2"></i>
                    Ada <strong><?= $jumlah_pending ?></strong> transaksi dengan status <b>Pending</b>.
                    <?php if ($jumlah_pending <= 10): ?>
                        <small class="d-block d-md-inline ml-md-2">(Kumpulkan minimal 11 transaksi untuk fitur Posting Otomatis)</small>
                    <?php endif; ?>
                </div>
                
                <?php if ($jumlah_pending > 10): ?>
                    <a href="<?= base_url('transaksi/posting_otomatis') ?>" class="btn btn-sm btn-warning font-weight-bold shadow-sm" onclick="return confirm('Apakah Anda yakin ingin memposting <?= $jumlah_pending ?> transaksi sekaligus ke Buku Besar?');">
                        <i class="fas fa-rocket mr-1"></i> Posting Semua
                    </a>
                <?php else: ?>
                    <button class="btn btn-sm btn-secondary disabled" disabled style="opacity: 0.7;">
                        <i class="fas fa-lock mr-1"></i> Auto Post Locked
                    </button>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="table-responsive mt-3">
            
            <!-- TAMPILAN 1: MODE RINGKAS -->
            <?php if ($filter['mode'] == 'ringkas'): ?>
                <table class="table table-bordered table-hover" width="100%" cellspacing="0">
                    <thead class="thead-light">
                        <tr>
                            <th width="12%">Tanggal</th>
                            <th width="12%">No. Bukti</th>
                            <th>Keterangan Transaksi</th>
                            <th width="10%" class="text-center">Jenis</th>
                            <th width="8%" class="text-center">Status</th> <!-- Kolom Status -->
                            <th width="15%" class="text-right">Total Nilai</th>
                            <th width="12%" class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $grandTotalRingkas = 0;
                        foreach($jurnal as $j): 
                            $nilai = $j['total_nilai'] ?? 0;
                            $grandTotalRingkas += $nilai;
                            
                            $jenis = $j['jenis_transaksi'] ?? 'Umum';
                            $badgeClass = 'badge-jenis-umum';
                            if($jenis == 'Penjualan') $badgeClass = 'badge-jenis-penjualan';
                            if($jenis == 'Pembelian') $badgeClass = 'badge-jenis-pembelian';
                            if($jenis == 'Koreksi') $badgeClass = 'badge-jenis-koreksi';
                            if($jenis == 'Penyesuaian') $badgeClass = 'badge-jenis-penyesuaian';
                            if($jenis == 'Penutup') $badgeClass = 'badge-jenis-penutup';

                            // Badge Status
                            $status = $j['status_posting'] ?? 'Pending';
                            $statusBadge = ($status == 'Posted') ? 'badge-status-posted' : 'badge-status-pending';
                        ?>
                        <tr>
                            <td class="font-weight-bold text-gray-700"><?= date('d/m/Y', strtotime($j['tgl_jurnal'])) ?></td>
                            <td><span class="badge badge-light border text-gray-800 px-2"><?= $j['no_bukti'] ?></span></td>
                            <td><?= $j['keterangan'] ?></td>
                            <td class="text-center">
                                <span class="badge <?= $badgeClass ?> px-2 py-1 shadow-sm"><?= $jenis ?></span>
                            </td>
                            <td class="text-center">
                                <span class="badge <?= $statusBadge ?> px-2 py-1"><?= $status ?></span>
                            </td>
                            <td class="text-right font-weight-bold text-success">
                                Rp <?= number_format($nilai, 0, ',', '.') ?>
                            </td>
                            <td class="text-center">
                                <div class="btn-group" role="group">
                                    <?php if ($status == 'Pending'): ?>
                                        <!-- Tombol Posting Manual -->
                                        <a href="<?= base_url('transaksi/posting/'.$j['id_jurnal']) ?>" class="btn btn-success btn-sm" title="Post ke Buku Besar">
                                            <i class="fas fa-check"></i>
                                        </a>
                                        <a href="<?= base_url('transaksi/detail/'.$j['id_jurnal']) ?>" class="btn btn-info btn-sm" title="Lihat">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <!-- Delete hanya jika Pending -->
                                        <form action="<?= base_url('transaksi/delete/'.$j['id_jurnal']) ?>" method="post" class="d-inline">
                                            <?= csrf_field(); ?>
                                            <input type="hidden" name="_method" value="DELETE">
                                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Hapus data transaksi ini?')" title="Hapus">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <!-- Jika Posted, hanya bisa Lihat & Cetak -->
                                        <a href="<?= base_url('transaksi/detail/'.$j['id_jurnal']) ?>" class="btn btn-info btn-sm" title="Lihat">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?= base_url('transaksi/cetak/'.$j['id_jurnal']) ?>" target="_blank" class="btn btn-secondary btn-sm" title="Cetak">
                                            <i class="fas fa-print"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($jurnal)): ?>
                            <tr><td colspan="7" class="text-center py-5">Belum ada data transaksi untuk kategori ini.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>

            <!-- TAMPILAN 2: MODE DETAIL -->
            <?php else: ?>
                <table class="table table-bordered table-striped" width="100%" cellspacing="0">
                    <thead class="bg-dark text-white text-center">
                        <tr>
                            <th width="10%">Tanggal</th>
                            <th width="12%">No. Bukti</th>
                            <th width="8%">Jenis</th>
                            <th width="8%">Status</th> <!-- Kolom Status -->
                            <th>Keterangan / Nama Akun</th>
                            <th width="8%">Ref</th>
                            <th width="15%">Debit</th>
                            <th width="15%">Kredit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $currentBukti = '';
                        foreach($jurnal as $j): 
                            $isNewGroup = ($j['no_bukti'] != $currentBukti);
                            $currentBukti = $j['no_bukti'];
                            
                            $jenis = $j['jenis_transaksi'] ?? 'Umum';
                            $textClass = 'text-primary';
                            if($jenis == 'Penjualan') $textClass = 'text-success';
                            if($jenis == 'Pembelian') $textClass = 'text-danger';
                            if($jenis == 'Penyesuaian') $textClass = 'text-info';

                            // Status Logic
                            $status = $j['status_posting'] ?? 'Pending';
                            $badgeStatus = ($status == 'Posted') ? 'badge-success' : 'badge-warning';
                        ?>
                        <tr class="journal-row">
                            <td class="text-center font-weight-bold">
                                <?= $isNewGroup ? date('d/m/Y', strtotime($j['tgl_jurnal'])) : '' ?>
                            </td>
                            <td>
                                <?= $isNewGroup ? '<span class="badge badge-light border text-gray-800">'.$j['no_bukti'].'</span>' : '' ?>
                            </td>
                            <td class="text-center font-weight-bold <?= $textClass ?> small">
                                <?= $isNewGroup ? strtoupper($jenis) : '' ?>
                            </td>
                            <td class="text-center">
                                <?= $isNewGroup ? '<span class="badge '.$badgeStatus.'">'.$status.'</span>' : '' ?>
                            </td>
                            <td class="<?= ($j['kredit'] > 0) ? 'kredit-indent' : 'font-weight-bold text-gray-800' ?>">
                                <?= $j['nama_akun'] ?>
                                <?php if($isNewGroup): ?>
                                    <br><small class="text-muted font-italic ml-2">(<?= $j['keterangan'] ?>)</small>
                                <?php endif; ?>
                            </td>
                            <td class="text-center"><?= $j['kode_akun'] ?></td>
                            <td class="text-right">
                                <?= ($j['debit'] > 0) ? number_format($j['debit'], 0, ',', '.') : '-' ?>
                            </td>
                            <td class="text-right">
                                <?= ($j['kredit'] > 0) ? number_format($j['kredit'], 0, ',', '.') : '-' ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>

        </div>

        <!-- Pagination -->
        <div class="d-flex justify-content-end mt-3">
            <?= $pager_links ?>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>