<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Input Jurnal Penyesuaian (AJP)</h1>
    <a href="<?= base_url('transaksi') ?>" class="btn btn-secondary btn-sm shadow-sm">
        <i class="fas fa-arrow-left fa-sm text-white-50"></i> Kembali ke Riwayat
    </a>
</div>

<!-- Menggunakan Border Warning (Kuning/Orange) untuk membedakan -->
<div class="card shadow mb-4 border-left-warning">
    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-warning"><i class="fas fa-balance-scale mr-2"></i>Formulir Penyesuaian Akhir Periode</h6>
        <div class="text-right small text-muted">Input untuk Penyusutan, Sewa, Akrual, dll.</div>
    </div>
    <div class="card-body">
        
        <?php if(session()->getFlashdata('error')): ?>
            <div class="alert alert-danger border-left-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-circle mr-2"></i>
                <?= session()->getFlashdata('error') ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <form action="<?= base_url('transaksi/store') ?>" method="post" id="formJurnal">
            <?= csrf_field() ?>
            
            <!-- INPUT TERSEMBUNYI: MENANDAI INI ADALAH PENYESUAIAN -->
            <input type="hidden" name="jenis_transaksi" value="Penyesuaian">
            
            <!-- SECTION 1: HEADER TRANSAKSI -->
            <div class="bg-gray-100 p-3 rounded mb-4 border-bottom-warning" style="border-bottom: 3px solid #f6c23e;">
                <div class="row">
                    <div class="col-lg-3 col-md-6 mb-3 mb-lg-0">
                        <label class="font-weight-bold text-gray-700">No. Bukti (AJP)</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-white border-right-0"><i class="fas fa-barcode text-gray-400"></i></span>
                            </div>
                            <!-- No Bukti Otomatis AJP-000X -->
                            <input type="text" name="no_bukti" class="form-control border-left-0 font-weight-bold text-warning" 
                                   value="<?= $no_bukti_auto ?? 'AJP-0001' ?>" readonly>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-3 mb-lg-0">
                        <label class="font-weight-bold text-gray-700">Tanggal Penyesuaian</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-white border-right-0"><i class="fas fa-calendar-alt text-gray-400"></i></span>
                            </div>
                            <!-- Biasanya AJP dibuat di akhir bulan -->
                            <input type="date" name="tgl_jurnal" class="form-control border-left-0" value="<?= date('Y-m-t') ?>" required>
                            <small class="text-muted ml-2">Default: Akhir Bulan Ini</small>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <label class="font-weight-bold text-gray-700">Keterangan / Deskripsi</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-white border-right-0"><i class="fas fa-sticky-note text-gray-400"></i></span>
                            </div>
                            <input type="text" name="keterangan" class="form-control border-left-0" placeholder="Contoh: Penyesuaian Sewa Dibayar Dimuka" required>
                        </div>
                    </div>
                </div>
            </div>

            <!-- SECTION 2: DETAIL JURNAL (Sama persis dengan jurnal umum) -->
            <div class="table-responsive mb-4">
                <table class="table table-bordered table-hover" id="table-jurnal">
                    <thead class="thead-dark text-center">
                        <tr>
                            <th width="40%">Akun / Rekening</th>
                            <th width="25%">Debit (Rp)</th>
                            <th width="25%">Kredit (Rp)</th>
                            <th width="10%"><i class="fas fa-cog"></i></th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Baris 1 (Debit) -->
                        <tr class="bg-white">
                            <td>
                                <select name="kode_akun[]" class="form-control select-akun border-left-primary" required>
                                    <option value="">-- Pilih Akun (Debit) --</option>
                                    <?php foreach($akun as $row): ?>
                                        <option value="<?= $row['kode_akun'] ?>"><?= $row['kode_akun'] ?> - <?= $row['nama_akun'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <div class="input-group input-group-sm">
                                    <div class="input-group-prepend"><span class="input-group-text">Rp</span></div>
                                    <input type="number" name="debit[]" class="form-control input-debit font-weight-bold text-success" value="0" min="0" onfocus="this.select()">
                                </div>
                            </td>
                            <td>
                                <div class="input-group input-group-sm">
                                    <div class="input-group-prepend"><span class="input-group-text">Rp</span></div>
                                    <input type="number" name="kredit[]" class="form-control input-kredit font-weight-bold text-danger" value="0" min="0" readonly onfocus="this.select()">
                                </div>
                            </td>
                            <td class="text-center">
                                <button type="button" class="btn btn-outline-danger btn-sm btn-hapus disabled" disabled><i class="fas fa-times"></i></button>
                            </td>
                        </tr>
                        <!-- Baris 2 (Kredit) -->
                        <tr class="bg-light">
                            <td>
                                <select name="kode_akun[]" class="form-control select-akun border-left-danger" required>
                                    <option value="">-- Pilih Akun (Kredit) --</option>
                                    <?php foreach($akun as $row): ?>
                                        <option value="<?= $row['kode_akun'] ?>"><?= $row['kode_akun'] ?> - <?= $row['nama_akun'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <div class="input-group input-group-sm">
                                    <div class="input-group-prepend"><span class="input-group-text">Rp</span></div>
                                    <input type="number" name="debit[]" class="form-control input-debit font-weight-bold text-success" value="0" min="0" readonly onfocus="this.select()">
                                </div>
                            </td>
                            <td>
                                <div class="input-group input-group-sm">
                                    <div class="input-group-prepend"><span class="input-group-text">Rp</span></div>
                                    <input type="number" name="kredit[]" class="form-control input-kredit font-weight-bold text-danger" value="0" min="0" onfocus="this.select()">
                                </div>
                            </td>
                            <td class="text-center">
                                <button type="button" class="btn btn-outline-danger btn-sm btn-hapus disabled" disabled><i class="fas fa-times"></i></button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="d-flex justify-content-center mb-4">
                <button type="button" class="btn btn-warning btn-sm shadow-sm rounded-pill px-4" id="btn-tambah">
                    <i class="fas fa-plus mr-1"></i> Tambah Baris Akun
                </button>
            </div>

            <!-- SECTION 3: TOTAL & SUMMARY -->
            <div class="row justify-content-end">
                <div class="col-lg-5">
                    <div class="card bg-gray-100 border-0">
                        <div class="card-body p-3">
                            <div class="d-flex justify-content-between mb-2">
                                <span class="font-weight-bold text-gray-600">Total Debit:</span>
                                <span class="font-weight-bold text-success" id="display-total-debit">Rp 0</span>
                            </div>
                            <div class="d-flex justify-content-between mb-3">
                                <span class="font-weight-bold text-gray-600">Total Kredit:</span>
                                <span class="font-weight-bold text-danger" id="display-total-kredit">Rp 0</span>
                            </div>
                            <div class="d-flex justify-content-between align-items-center p-2 rounded" id="status-balance">
                                <span class="font-weight-bold text-white small text-uppercase">Status:</span>
                                <span class="font-weight-bold text-white" id="text-balance">SEIMBANG</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <hr class="my-4">

            <div class="d-flex justify-content-end">
                <a href="<?= base_url('transaksi') ?>" class="btn btn-light border mr-2">Batal</a>
                <button type="submit" class="btn btn-warning btn-lg shadow px-5" id="btn-simpan">
                    <i class="fas fa-save mr-2"></i> Simpan Penyesuaian
                </button>
            </div>
        </form>
    </div>
</div>

<?= $this->endSection(); ?>

<?= $this->section('scripts'); ?>
<!-- Script Hitung Total (Sama dengan create.php, boleh di-extract ke file JS terpisah) -->
<script>
    $(document).ready(function() {
        hitungTotal();
        $(document).on('keyup change', '.input-debit, .input-kredit', function() {
            let row = $(this).closest('tr');
            if ($(this).hasClass('input-debit')) {
                if(parseFloat($(this).val()) > 0) row.find('.input-kredit').val(0);
            } else {
                if(parseFloat($(this).val()) > 0) row.find('.input-debit').val(0);
            }
            hitungTotal();
        });
        $('#btn-tambah').click(function() {
            let row = $('#table-jurnal tbody tr:last').clone();
            row.find('input').val(0);
            row.find('select').val('');
            row.find('input').removeAttr('readonly'); 
            row.find('.btn-hapus').removeClass('disabled').removeAttr('disabled');
            row.find('select').removeClass('border-left-primary border-left-danger');
            row.hide().appendTo('#table-jurnal tbody').fadeIn(300);
        });
        $(document).on('click', '.btn-hapus', function() {
            if ($('#table-jurnal tbody tr').length > 2) {
                $(this).closest('tr').fadeOut(300, function(){ $(this).remove(); hitungTotal(); });
            } else { alert('Minimal harus ada 2 baris transaksi.'); }
        });
        function hitungTotal() {
            let sumDebit = 0; let sumKredit = 0;
            $('.input-debit').each(function() { sumDebit += parseFloat($(this).val()) || 0; });
            $('.input-kredit').each(function() { sumKredit += parseFloat($(this).val()) || 0; });
            $('#display-total-debit').text('Rp ' + new Intl.NumberFormat('id-ID').format(sumDebit));
            $('#display-total-kredit').text('Rp ' + new Intl.NumberFormat('id-ID').format(sumKredit));
            let statusBox = $('#status-balance'); let statusText = $('#text-balance'); let btnSimpan = $('#btn-simpan');
            statusBox.removeClass('bg-success bg-danger bg-warning');
            if (sumDebit === 0 && sumKredit === 0) {
                statusBox.addClass('bg-warning'); statusText.text('BELUM ADA NILAI'); btnSimpan.attr('disabled', true);
            } else if (sumDebit === sumKredit) {
                statusBox.addClass('bg-success'); statusText.html('<i class="fas fa-check mr-1"></i> SEIMBANG'); btnSimpan.removeAttr('disabled');
            } else {
                statusBox.addClass('bg-danger'); statusText.html('<i class="fas fa-times mr-1"></i> TIDAK SEIMBANG'); btnSimpan.attr('disabled', true);
            }
        }
    });
</script>
<?= $this->endSection(); ?>